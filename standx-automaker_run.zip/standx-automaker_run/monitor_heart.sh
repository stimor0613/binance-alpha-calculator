#!/bin/bash
#
# 启动心跳监控脚本
# 建议在 screen 中运行: screen -S monitor ./monitor_heart.sh
#

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# 激活虚拟环境
if [ -d "$SCRIPT_DIR/venv" ]; then
    source "$SCRIPT_DIR/venv/bin/activate"
fi

python "$SCRIPT_DIR/src/monitor.py"
