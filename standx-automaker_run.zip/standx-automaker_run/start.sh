#!/bin/bash

echo "启动 StandX 交易所工具..."

# 检查虚拟环境
if [ ! -d "venv" ]; then
    echo "[错误] 未找到虚拟环境，请先运行 ./install.sh"
    exit 1
fi

# 检查.env文件
if [ ! -f ".env" ]; then
    echo "[错误] 未找到 .env 文件，请先运行 ./install.sh 并配置私钥"
    exit 1
fi

# 激活虚拟环境并运行
source venv/bin/activate
python3 main.py
