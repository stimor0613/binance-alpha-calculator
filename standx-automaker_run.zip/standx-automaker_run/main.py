"""
StandX 交易所工具 - 主程序
"""

import os
import sys
import select
import threading
import asyncio
import json
import time
import websockets
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

from config import (
    SUPPORTED_SYMBOLS, DEFAULT_SYMBOL, DEFAULT_TP_PERCENT, DEFAULT_SL_PERCENT,
    WS_STREAM_URL, WS_API_URL, MIN_POSITION_THRESHOLD, MAKER_DEFAULT_SIZE,
    MAKER_REFRESH_PERCENT, MAKER_DANGER_PERCENT,
    VOLATILITY_THRESHOLD_1, VOLATILITY_THRESHOLD_2, VOLATILITY_THRESHOLD_3,
    VOLATILITY_DISTANCE_1, VOLATILITY_DISTANCE_2, VOLATILITY_DISTANCE_3
)
from src.auth import StandXAuth
from src.rest_client import StandXClient
from src.volume_bot import LimitMarketVolumeBot
from src.maker_bot import MakerPointsBot


class StandXTrader:
    """StandX 交易工具"""

    def __init__(self):
        self.current_symbol = DEFAULT_SYMBOL
        self.client: StandXClient = None
        self.auth: StandXAuth = None

    def initialize(self):
        """初始化客户端连接"""
        print("=" * 60)
        print("       StandX Maker Bot")
        print("       作者：岳来岳会赚")
        print("  Twitter: @188888_x  TG: @Pacemak1r_8")
        print("  Discord: https://discord.gg/KydzuuYp")
        print("  注册立享5%积分加成: standx.com/referral?code=YP9993")
        print("=" * 60)

        # 获取私钥
        private_key = os.getenv("PRIVATE_KEY")
        ed25519_key = os.getenv("ED25519_KEY")
        chain = os.getenv("CHAIN", "bsc")

        if not private_key:
            print("\n[错误] 未找到私钥，请在 .env 文件中配置 PRIVATE_KEY")
            sys.exit(1)

        try:
            # 初始化认证
            self.auth = StandXAuth(private_key, chain, ed25519_key)
            self.auth.login()

            # 初始化REST客户端
            self.client = StandXClient(self.auth)

            print(f"钱包: {self.auth.address}")

        except Exception as e:
            print(f"\n[错误] 初始化失败: {e}")
            sys.exit(1)

    def print_menu(self):
        """打印主菜单"""
        print("\n" + "=" * 50)
        print(f"  当前币种: {self.current_symbol}")
        print("=" * 50)
        print("\n  [1] 挂单做市机器人")
        print("  [2] 刷量机器人")
        print("  [3] 查看余额")
        print("  [4] 查看持仓")
        print("  [5] 查询委托")
        print("  [6] 撤销委托")
        print("  [7] 一键平仓")
        print("  [8] 调试工具")
        print("  [0] 退出")
        print("-" * 50)

    def print_debug_menu(self):
        """打印调试菜单"""
        print("\n" + "-" * 40)
        print("  调试工具")
        print("-" * 40)
        print("  [1] 切换币种")
        print("  [2] 查看实时价格 (WebSocket)")
        print("  [3] 实时持仓监控 (WebSocket)")
        print("  [4] 实时订单监控 (WebSocket)")
        print("  [5] 获取深度数据原始返回")
        print("  [6] 市价开多 (止盈止损7%)")
        print("  [7] 市价开空 (止盈止损7%)")
        print("  [8] 限价开多 (PostOnly)")
        print("  [9] 限价开空 (PostOnly)")
        print("  [0] 返回主菜单")
        print("-" * 40)

    def debug_tools(self):
        """调试工具子菜单"""
        while True:
            self.print_debug_menu()
            choice = input("\n请选择: ")

            if choice == "1":
                self.change_symbol()
            elif choice == "2":
                self.show_price()
            elif choice == "3":
                self.show_realtime_position()
            elif choice == "4":
                self.show_realtime_orders()
            elif choice == "5":
                self.debug_depth()
            elif choice == "6":
                self.market_long()
            elif choice == "7":
                self.market_short()
            elif choice == "8":
                self.limit_long()
            elif choice == "9":
                self.limit_short()
            elif choice == "0":
                break
            else:
                print("\n无效选择")

    def show_price(self):
        """实时显示价格（WebSocket）"""
        print(f"\n正在连接 {self.current_symbol} 实时价格...")
        print("按回车键退出\n")

        latest_price = {"bid": "---", "ask": "---"}
        stop_flag = threading.Event()
        connected = threading.Event()

        def run_ws():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

            async def ws_task():
                try:
                    async with websockets.connect(
                        WS_STREAM_URL,
                        ping_interval=None,
                        ping_timeout=None
                    ) as conn:
                        connected.set()

                        # 订阅深度数据获取买卖1
                        await conn.send(json.dumps({
                            "subscribe": {
                                "channel": "depth_book",
                                "symbol": self.current_symbol
                            }
                        }))

                        while not stop_flag.is_set():
                            try:
                                message = await asyncio.wait_for(conn.recv(), timeout=0.5)

                                if message == "ping":
                                    await conn.send("pong")
                                    continue

                                data = json.loads(message)
                                if data.get("channel") == "depth_book":
                                    depth_data = data.get("data", {})
                                    bids = depth_data.get("bids", [])
                                    asks = depth_data.get("asks", [])
                                    if bids:
                                        best_bid = max(bids, key=lambda x: float(x[0]))
                                        latest_price["bid"] = best_bid[0]
                                    if asks:
                                        best_ask = min(asks, key=lambda x: float(x[0]))
                                        latest_price["ask"] = best_ask[0]

                            except asyncio.TimeoutError:
                                continue
                            except Exception:
                                pass

                except Exception as e:
                    if not stop_flag.is_set():
                        print(f"\n[WS] 连接错误: {e}")

            loop.run_until_complete(ws_task())

        ws_thread = threading.Thread(target=run_ws, daemon=True)
        ws_thread.start()
        connected.wait(timeout=5)

        try:
            while True:
                print(f"\r  {self.current_symbol}  买1: {latest_price['bid']}  |  卖1: {latest_price['ask']}    ", end="", flush=True)

                if sys.stdin in select.select([sys.stdin], [], [], 0.3)[0]:
                    sys.stdin.readline()
                    break

        except KeyboardInterrupt:
            pass
        finally:
            stop_flag.set()
            print("\n\n已退出实时价格")

    def show_balance(self):
        """显示钱包余额"""
        try:
            result = self.client.get_balance()
            print(f"\n钱包余额:")

            if isinstance(result, dict):
                # API 直接返回余额字典
                equity = result.get("equity", "0")
                balance = result.get("balance", "0")
                available = result.get("cross_available", "0")
                margin = result.get("cross_margin", "0")
                upnl = result.get("upnl", "0")
                pnl_24h = result.get("pnl_24h", "0")

                print(f"  账户权益: {float(equity):.4f} DUSD")
                print(f"  账户余额: {float(balance):.4f} DUSD")
                print(f"  可用余额: {float(available):.4f} DUSD")
                print(f"  占用保证金: {float(margin):.4f} DUSD")
                print(f"  未实现盈亏: {float(upnl):.4f} DUSD")
                print(f"  24h盈亏: {float(pnl_24h):.4f} DUSD")
            else:
                print(f"  {result}")

        except Exception as e:
            print(f"\n[错误] 查询余额失败: {e}")

    def show_positions(self):
        """显示当前持仓"""
        try:
            positions = self.client.get_positions()
            print(f"\n当前持仓:")

            if not positions:
                print("  无持仓")
                return

            data = positions.get("data", positions) if isinstance(positions, dict) else positions

            if isinstance(data, list):
                if len(data) == 0:
                    print("  无持仓")
                    return

                # 过滤掉数量为0的仓位
                active_positions = [pos for pos in data if float(pos.get("qty", 0)) != 0]

                if len(active_positions) == 0:
                    print("  无持仓")
                    return

                for pos in active_positions:
                    symbol = pos.get("symbol", "---")
                    qty = pos.get("qty", "0")
                    entry_price = pos.get("entry_price", "---")
                    upnl = pos.get("upnl", "---")
                    leverage = pos.get("leverage", "---")
                    liq_price = pos.get("liq_price", "---")

                    qty_float = float(qty)
                    direction = "多" if qty_float > 0 else "空"

                    print(f"\n  {symbol}:")
                    print(f"    方向: {direction}")
                    print(f"    数量: {abs(qty_float)}")
                    print(f"    开仓价: {entry_price}")
                    print(f"    强平价: {liq_price}")
                    print(f"    未实现盈亏: {upnl}")
                    print(f"    杠杆: {leverage}x")
            else:
                print(f"  {data}")

        except Exception as e:
            print(f"\n[错误] 查询持仓失败: {e}")

    def market_long(self):
        """市价开多"""
        try:
            size = input("\n请输入开仓数量: ")
            size = float(size)

            if size <= 0:
                print("[错误] 数量必须大于0")
                return

            # 从REST API获取价格
            price_data = self.client.get_symbol_price(self.current_symbol)
            current_price = float(price_data.get("last_price", 0))

            print(f"\n正在开多 {self.current_symbol}...")
            print(f"  当前价格: {current_price}")
            if current_price:
                tp = current_price * 1.07
                sl = current_price * 0.93
                print(f"  止盈价格: {tp:.2f} (+7%)")
                print(f"  止损价格: {sl:.2f} (-7%)")

            result = self.client.market_long(
                symbol=self.current_symbol,
                size=size,
                current_price=current_price if current_price else None
            )
            print(f"\n[成功] 订单已提交")

        except ValueError:
            print("[错误] 请输入有效的数字")
        except Exception as e:
            print(f"\n[错误] 开多失败: {e}")

    def market_short(self):
        """市价开空"""
        try:
            size = input("\n请输入开仓数量: ")
            size = float(size)

            if size <= 0:
                print("[错误] 数量必须大于0")
                return

            # 从REST API获取价格
            price_data = self.client.get_symbol_price(self.current_symbol)
            current_price = float(price_data.get("last_price", 0))

            print(f"\n正在开空 {self.current_symbol}...")
            print(f"  当前价格: {current_price}")
            if current_price:
                tp = current_price * 0.93
                sl = current_price * 1.07
                print(f"  止盈价格: {tp:.2f} (-7%)")
                print(f"  止损价格: {sl:.2f} (+7%)")

            result = self.client.market_short(
                symbol=self.current_symbol,
                size=size,
                current_price=current_price if current_price else None
            )
            print(f"\n[成功] 订单已提交")

        except ValueError:
            print("[错误] 请输入有效的数字")
        except Exception as e:
            print(f"\n[错误] 开空失败: {e}")

    def limit_long(self):
        """限价开多"""
        try:
            size = input("\n请输入开仓数量: ")
            size = float(size)

            if size <= 0:
                print("[错误] 数量必须大于0")
                return

            print(f"\n正在限价开多 {self.current_symbol}...")
            print("  自动获取买1价...")

            result, price = self.client.limit_long(
                symbol=self.current_symbol,
                size=size,
                post_only=True
            )

            print(f"  挂单价格: {price}")
            print(f"\n[成功] 限价多单已提交 (PostOnly)")

        except ValueError:
            print("[错误] 请输入有效的数字")
        except Exception as e:
            print(f"\n[错误] 限价开多失败: {e}")

    def limit_short(self):
        """限价开空"""
        try:
            size = input("\n请输入开仓数量: ")
            size = float(size)

            if size <= 0:
                print("[错误] 数量必须大于0")
                return

            print(f"\n正在限价开空 {self.current_symbol}...")
            print("  自动获取卖1价...")

            result, price = self.client.limit_short(
                symbol=self.current_symbol,
                size=size,
                post_only=True
            )

            print(f"  挂单价格: {price}")
            print(f"\n[成功] 限价空单已提交 (PostOnly)")

        except ValueError:
            print("[错误] 请输入有效的数字")
        except Exception as e:
            print(f"\n[错误] 限价开空失败: {e}")

    def close_position(self):
        """一键平仓"""
        try:
            print(f"\n正在平仓 {self.current_symbol}...")

            # 先显示当前持仓
            positions = self.client.get_positions(self.current_symbol)
            data = positions.get("data", positions) if isinstance(positions, dict) else positions

            if not data or len(data) == 0:
                print("  当前无持仓")
                return

            confirm = input("确认平仓? (y/n): ")
            if confirm.lower() != 'y':
                print("已取消")
                return

            result = self.client.close_position(self.current_symbol)

            if result:
                print(f"\n[成功] 平仓订单已提交")
                print(f"  订单ID: {result.get('data', {}).get('orderId', result)}")
            else:
                print("  当前无持仓")

        except Exception as e:
            print(f"\n[错误] 平仓失败: {e}")

    def show_open_orders(self):
        """查询委托订单"""
        try:
            print(f"\n正在查询 {self.current_symbol} 委托订单...")
            response = self.client.get_open_orders(self.current_symbol)

            # 处理响应格式: {"code": 0, "result": [...]}
            if isinstance(response, dict):
                orders = response.get("result", response.get("data", []))
            else:
                orders = response

            if not orders or len(orders) == 0:
                print("  当前无委托订单")
                return

            print(f"\n当前委托订单 ({len(orders)} 个):")
            for order in orders:
                order_id = order.get("id", "---")
                side = order.get("side", "---")
                price = order.get("price", "---")
                qty = order.get("qty", "---")
                status = order.get("status", "---")
                order_type = order.get("order_type", "---")
                time_in_force = order.get("time_in_force", "---")

                side_cn = "买入" if side == "buy" else "卖出" if side == "sell" else side
                print(f"\n  订单ID: {order_id}")
                print(f"    方向: {side_cn}, 类型: {order_type}, TIF: {time_in_force}")
                print(f"    价格: {price}, 数量: {qty}")
                print(f"    状态: {status}")

        except Exception as e:
            print(f"\n[错误] 查询委托订单失败: {e}")

    def cancel_all_orders(self):
        """撤销所有委托"""
        try:
            print(f"\n正在查询 {self.current_symbol} 委托订单...")
            response = self.client.get_open_orders(self.current_symbol)

            # 处理响应格式: {"code": 0, "result": [...]}
            if isinstance(response, dict):
                orders = response.get("result", response.get("data", []))
            else:
                orders = response

            if not orders or len(orders) == 0:
                print("  当前无委托订单")
                return

            print(f"  找到 {len(orders)} 个委托订单")
            confirm = input("确认撤销所有委托? (y/n): ")
            if confirm.lower() != 'y':
                print("已取消")
                return

            print("正在撤销...")
            results = self.client.cancel_all_orders(self.current_symbol)

            success_count = sum(1 for r in results if r.get("status") == "success")
            failed_count = len(results) - success_count

            print(f"\n[完成] 成功撤销 {success_count} 个, 失败 {failed_count} 个")

            if failed_count > 0:
                for r in results:
                    if r.get("status") == "failed":
                        print(f"  订单 {r.get('order_id')} 撤销失败: {r.get('error')}")

        except Exception as e:
            print(f"\n[错误] 撤销委托失败: {e}")

    def debug_depth(self):
        """调试: 获取深度数据原始返回"""
        try:
            print(f"\n正在获取 {self.current_symbol} 深度数据...")
            depth = self.client.get_depth_book(self.current_symbol, limit=5)
            print(f"\n原始返回数据:")
            print(json.dumps(depth, indent=2, ensure_ascii=False))

            # 解析买卖1
            # 注意：bids从低到高排序，买1是最后一个；asks从低到高排序，卖1是第一个
            bids = depth.get("bids", [])
            asks = depth.get("asks", [])
            if bids:
                print(f"\n买1价: {bids[-1][0]}, 数量: {bids[-1][1]} (bids最后一个)")
            if asks:
                print(f"卖1价: {asks[0][0]}, 数量: {asks[0][1]} (asks第一个)")

        except Exception as e:
            print(f"\n[错误] 获取深度数据失败: {e}")

    def show_realtime_position(self):
        """实时持仓监控（WebSocket）"""
        print(f"\n正在连接实时持仓监控...")
        print("按回车键退出\n")

        current_position = {"data": None}
        stop_flag = threading.Event()
        connected = threading.Event()

        def format_position(pos):
            """格式化持仓显示"""
            if not pos:
                return "当前无持仓"
            qty = float(pos.get("qty", 0))
            if qty == 0:
                return "当前无持仓"
            direction = "多" if qty > 0 else "空"
            symbol = pos.get("symbol", "---")
            entry_price = pos.get("entry_price", "---")
            leverage = pos.get("leverage", "---")
            return f"{symbol}: {direction} {abs(qty)} @ {entry_price} ({leverage}x)"

        def display_position():
            """显示当前持仓"""
            output = format_position(current_position["data"])
            print(f"\r  {output}                                        ", end="", flush=True)

        def run_ws():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

            async def ws_task():
                try:
                    token = self.auth.get_token()

                    async with websockets.connect(
                        WS_STREAM_URL,
                        ping_interval=None,
                        ping_timeout=None
                    ) as conn:
                        connected.set()

                        # 认证
                        auth_msg = {
                            "auth": {
                                "token": token,
                                "streams": [{"channel": "position"}]
                            }
                        }
                        await conn.send(json.dumps(auth_msg))

                        # 订阅持仓频道
                        subscribe_msg = {
                            "subscribe": {
                                "channel": "position"
                            }
                        }
                        await conn.send(json.dumps(subscribe_msg))

                        # 获取初始持仓快照（仅用于首次启动时显示）
                        try:
                            positions = self.client.get_positions()
                            data = positions.get("data", positions) if isinstance(positions, dict) else positions
                            if isinstance(data, list):
                                for pos in data:
                                    if float(pos.get("qty", 0)) != 0:
                                        current_position["data"] = pos
                                        break
                            display_position()
                        except:
                            pass

                        while not stop_flag.is_set():
                            try:
                                message = await asyncio.wait_for(conn.recv(), timeout=0.5)

                                if message == "ping":
                                    await conn.send("pong")
                                    continue

                                data = json.loads(message)
                                channel = data.get("channel")

                                if channel == "position":
                                    position_data = data.get("data", {})
                                    current_position["data"] = position_data
                                    display_position()

                            except asyncio.TimeoutError:
                                continue
                            except:
                                pass

                except Exception as e:
                    if not stop_flag.is_set():
                        print(f"\n连接错误: {e}")

            loop.run_until_complete(ws_task())

        ws_thread = threading.Thread(target=run_ws, daemon=True)
        ws_thread.start()
        connected.wait(timeout=10)

        if not connected.is_set():
            print("[错误] 连接超时")
            return

        try:
            while True:
                if sys.stdin in select.select([sys.stdin], [], [], 0.5)[0]:
                    sys.stdin.readline()
                    break

        except KeyboardInterrupt:
            pass
        finally:
            stop_flag.set()
            print("\n")

    def show_realtime_orders(self):
        """实时订单监控（WebSocket）"""
        print(f"\n正在连接实时订单监控...")
        print("按回车键退出\n")

        stop_flag = threading.Event()
        connected = threading.Event()
        order_count = {"value": 0}

        def format_order(order):
            """格式化订单显示"""
            order_id = order.get("id", "---")
            symbol = order.get("symbol", "---")
            side = order.get("side", "---")
            status = order.get("status", "---")
            order_type = order.get("order_type", "---")
            qty = order.get("qty", "---")
            price = order.get("price", "---")
            fill_qty = order.get("fill_qty", "0")
            fill_avg_price = order.get("fill_avg_price", "---")

            side_cn = "买入" if side == "buy" else "卖出" if side == "sell" else side
            status_cn = {
                "new": "新建",
                "partially_filled": "部分成交",
                "filled": "完全成交",
                "canceled": "已撤销",
                "rejected": "已拒绝",
                "expired": "已过期"
            }.get(status, status)

            return (f"[{status_cn}] {symbol} {side_cn} {order_type} "
                    f"数量:{qty} 价格:{price} 成交:{fill_qty}@{fill_avg_price} "
                    f"(ID:{order_id})")

        def on_order_update(order):
            """订单更新回调"""
            order_count["value"] += 1
            timestamp = order.get("updated_at", "")
            print(f"\n  #{order_count['value']} {format_order(order)}")
            print(f"      时间: {timestamp}")

        def run_ws():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

            async def ws_task():
                try:
                    token = self.auth.get_token()

                    async with websockets.connect(
                        WS_STREAM_URL,
                        ping_interval=None,
                        ping_timeout=None
                    ) as conn:
                        connected.set()

                        # 认证
                        auth_msg = {
                            "auth": {
                                "token": token,
                                "streams": [{"channel": "order"}]
                            }
                        }
                        await conn.send(json.dumps(auth_msg))

                        # 订阅订单频道
                        subscribe_msg = {
                            "subscribe": {
                                "channel": "order"
                            }
                        }
                        await conn.send(json.dumps(subscribe_msg))

                        print("  已连接，等待订单更新...")

                        while not stop_flag.is_set():
                            try:
                                message = await asyncio.wait_for(conn.recv(), timeout=0.5)

                                if message == "ping":
                                    await conn.send("pong")
                                    continue

                                data = json.loads(message)
                                channel = data.get("channel")

                                if channel == "order":
                                    order_data = data.get("data", {})
                                    on_order_update(order_data)

                            except asyncio.TimeoutError:
                                continue
                            except:
                                pass

                except Exception as e:
                    if not stop_flag.is_set():
                        print(f"\n连接错误: {e}")

            loop.run_until_complete(ws_task())

        ws_thread = threading.Thread(target=run_ws, daemon=True)
        ws_thread.start()
        connected.wait(timeout=10)

        if not connected.is_set():
            print("[错误] 连接超时")
            return

        try:
            while True:
                if sys.stdin in select.select([sys.stdin], [], [], 0.5)[0]:
                    sys.stdin.readline()
                    break

        except KeyboardInterrupt:
            pass
        finally:
            stop_flag.set()
            print(f"\n\n共收到 {order_count['value']} 条订单更新")

    def run_volume_bot(self):
        """运行限市刷量机器人"""
        try:
            print(f"\n限市刷量机器人 - {self.current_symbol}")
            print("-" * 40)

            # 输入下单数量
            size = input("请输入每次下单数量: ")
            size = float(size)

            if size <= 0:
                print("[错误] 数量必须大于0")
                return

            print(f"\n配置确认:")
            print(f"  交易对: {self.current_symbol}")
            print(f"  下单数量: {size}")
            print(f"  仓位阈值: {MIN_POSITION_THRESHOLD}")
            print(f"\n按回车键启动，运行后 Ctrl+C 停止...")
            input()

            # 创建机器人
            bot = LimitMarketVolumeBot(
                client=self.client,
                symbol=self.current_symbol,
                order_amount=size
            )

            # 在新线程中运行
            stop_flag = threading.Event()

            def run_bot():
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)

                async def bot_task():
                    try:
                        await bot.start()
                    except asyncio.CancelledError:
                        pass

                task = loop.create_task(bot_task())

                while not stop_flag.is_set():
                    loop.run_until_complete(asyncio.sleep(0.1))

                # 停止机器人
                loop.run_until_complete(bot.stop())

            bot_thread = threading.Thread(target=run_bot, daemon=True)
            bot_thread.start()

            # 等待 Ctrl+C 停止
            try:
                while bot_thread.is_alive():
                    time.sleep(0.5)
            except KeyboardInterrupt:
                pass
            finally:
                stop_flag.set()
                bot_thread.join(timeout=5)
                print("\n机器人已停止")

        except ValueError:
            print("[错误] 请输入有效的数字")
        except Exception as e:
            print(f"\n[错误] 运行机器人失败: {e}")

    def run_maker_bot(self):
        """运行 Maker Points 刷分机器人"""
        try:
            print(f"\nMaker Points 刷分机器人 - {self.current_symbol}")
            print("=" * 60)
            print(f"  刷新阈值: {MAKER_REFRESH_PERCENT:.0f}% | 危险阈值: {MAKER_DANGER_PERCENT:.0f}%")
            print(f"  1档(波动率<={VOLATILITY_THRESHOLD_1}%): 距离{VOLATILITY_DISTANCE_1:.0f}bp -> 刷新{VOLATILITY_DISTANCE_1 * MAKER_REFRESH_PERCENT / 100:.1f}bp 危险{VOLATILITY_DISTANCE_1 * MAKER_DANGER_PERCENT / 100:.1f}bp")
            print(f"  2档(波动率<={VOLATILITY_THRESHOLD_2}%): 距离{VOLATILITY_DISTANCE_2:.0f}bp -> 刷新{VOLATILITY_DISTANCE_2 * MAKER_REFRESH_PERCENT / 100:.1f}bp 危险{VOLATILITY_DISTANCE_2 * MAKER_DANGER_PERCENT / 100:.1f}bp")
            print(f"  3档(波动率<={VOLATILITY_THRESHOLD_3}%): 距离{VOLATILITY_DISTANCE_3:.0f}bp -> 刷新{VOLATILITY_DISTANCE_3 * MAKER_REFRESH_PERCENT / 100:.1f}bp 危险{VOLATILITY_DISTANCE_3 * MAKER_DANGER_PERCENT / 100:.1f}bp")
            print("=" * 60)

            # 输入下单数量
            size_str = input(f"请输入每边挂单数量 (默认{MAKER_DEFAULT_SIZE}): ").strip()
            size = float(size_str) if size_str else MAKER_DEFAULT_SIZE

            if size <= 0:
                print("[错误] 数量必须大于0")
                return

            print(f"\n按回车键启动，运行后 Ctrl+C 停止...")
            input()

            # 创建机器人 (WebSocket 版本需要 auth)
            bot = MakerPointsBot(
                client=self.client,
                auth=self.auth,
                symbol=self.current_symbol,
                order_size=size
            )

            # 在新线程中运行
            stop_flag = threading.Event()

            def run_bot():
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)

                async def bot_task():
                    try:
                        await bot.start()
                    except asyncio.CancelledError:
                        pass

                task = loop.create_task(bot_task())

                while not stop_flag.is_set():
                    loop.run_until_complete(asyncio.sleep(0.1))

                # 停止机器人
                loop.run_until_complete(bot.stop())

            bot_thread = threading.Thread(target=run_bot, daemon=True)
            bot_thread.start()

            # 等待 Ctrl+C 停止
            try:
                while bot_thread.is_alive():
                    time.sleep(0.5)
            except KeyboardInterrupt:
                pass
            finally:
                stop_flag.set()
                bot_thread.join(timeout=5)

        except ValueError:
            print("[错误] 请输入有效的数字")
        except Exception as e:
            print(f"\n[错误] 运行机器人失败: {e}")

    def change_symbol(self):
        """切换币种"""
        print("\n可选币种:")
        for i, symbol in enumerate(SUPPORTED_SYMBOLS, 1):
            marker = " <当前" if symbol == self.current_symbol else ""
            print(f"  [{i}] {symbol}{marker}")

        try:
            choice = input("\n请选择 (输入序号): ")
            index = int(choice) - 1

            if 0 <= index < len(SUPPORTED_SYMBOLS):
                new_symbol = SUPPORTED_SYMBOLS[index]
                if new_symbol != self.current_symbol:
                    self.current_symbol = new_symbol
                    print(f"\n已切换到 {new_symbol}")
                else:
                    print("\n已经是当前币种")
            else:
                print("\n无效选择")

        except ValueError:
            print("\n请输入有效的数字")

    def run(self):
        """运行主循环"""
        self.initialize()

        while True:
            self.print_menu()
            choice = input("\n请选择操作: ")

            if choice == "1":
                self.run_maker_bot()
            elif choice == "2":
                self.run_volume_bot()
            elif choice == "3":
                self.show_balance()
            elif choice == "4":
                self.show_positions()
            elif choice == "5":
                self.show_open_orders()
            elif choice == "6":
                self.cancel_all_orders()
            elif choice == "7":
                self.close_position()
            elif choice == "8":
                self.debug_tools()
            elif choice == "0":
                print("\n再见!")
                break
            else:
                print("\n无效选择，请重试")


def main():
    trader = StandXTrader()
    trader.run()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n程序已中断")
