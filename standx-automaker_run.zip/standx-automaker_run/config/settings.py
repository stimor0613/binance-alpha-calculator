# StandX 交易所配置

# API 端点 (主网)
BASE_URL = "https://perps.standx.com"
WS_STREAM_URL = "wss://perps.standx.com/ws-stream/v1"
WS_API_URL = "wss://perps.standx.com/ws-api/v1"
AUTH_URL = "https://api.standx.com"  # 认证API使用不同的域名

# 支持的交易对
SUPPORTED_SYMBOLS = ["BTC-USD", "ETH-USD", "SOL-USD"]

# 默认交易对
DEFAULT_SYMBOL = "BTC-USD"

# 默认止盈止损百分比
DEFAULT_TP_PERCENT = 5.0  # 止盈 5%
DEFAULT_SL_PERCENT = 5.0  # 止损 5%

# 默认杠杆
DEFAULT_LEVERAGE = 10

# WebSocket 重连设置
WS_RECONNECT_DELAY = 1  # 重连延迟（秒）
WS_MAX_RECONNECT_DELAY = 30  # 最大重连延迟（秒）
WS_PING_INTERVAL = 10  # Ping 间隔（秒）

# 刷量机器人设置
MIN_POSITION_THRESHOLD = 0.0001  # 最小持仓阈值（用于判断是否有仓位）

# Maker Points 机器人设置
MAKER_DEFAULT_SIZE = 0.0002  # 默认每边挂单数量
MAKER_MIN_ORDER_LIFETIME = 3.5  # 订单最小存活时间（秒），规则要求>3秒
MAKER_REFRESH_PERCENT = 25.0  # 刷新阈值: 价格变化超过挂单距离的此百分比则刷新
MAKER_DANGER_PERCENT = 35.0   # 危险阈值: 价格变化超过挂单距离的此百分比立即刷新

# 波动率检测设置
VOLATILITY_WINDOW = 30  # 波动率计算窗口（秒）

# 1档: 100% points 区间 (0-10 bps)
VOLATILITY_THRESHOLD_1 = 0.03  # 波动率阈值1 (%) - 波动率<=0.03%用8bp
VOLATILITY_DISTANCE_1 = 8.0    # 挂单距离 (bps) -> 刷新2bp, 危险2.8bp

# 2档: 50% points 区间 (10-30 bps)
VOLATILITY_THRESHOLD_2 = 0.05  # 波动率阈值2 (%) - 波动率<=0.06%用27bp
VOLATILITY_DISTANCE_2 = 27.0   # 挂单距离 (bps) -> 刷新6.75bp, 危险9.45bp

# 3档: 10% points 区间 (30-100 bps)
VOLATILITY_THRESHOLD_3 = 0.10  # 波动率阈值3 (%) - 波动率<=0.15%用95bp，超过则暂停
VOLATILITY_DISTANCE_3 = 95.0   # 挂单距离 (bps) -> 刷新23.75bp, 危险33.25bp

# 波动率 > 0.1% 时暂停挂单，等待恢复
