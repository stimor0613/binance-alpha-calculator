#!/bin/bash

echo "========================================"
echo "   StandX 交易所工具 - 安装部署"
echo "========================================"

# 检查Python版本
if ! command -v python3 &> /dev/null; then
    echo "[错误] 未找到 Python3，请先安装 Python 3.8+"
    exit 1
fi

PYTHON_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo "Python版本: $PYTHON_VERSION"

# 创建虚拟环境
echo ""
echo "正在创建虚拟环境..."
python3 -m venv venv

if [ ! -d "venv" ]; then
    echo "[错误] 创建虚拟环境失败"
    exit 1
fi

# 激活虚拟环境
source venv/bin/activate

# 升级pip
echo ""
echo "正在升级 pip..."
pip install --upgrade pip

# 安装依赖
echo ""
echo "正在安装依赖..."
pip install -r requirements.txt

if [ $? -ne 0 ]; then
    echo "[错误] 安装依赖失败"
    exit 1
fi

# 创建.env文件（如果不存在）
if [ ! -f ".env" ]; then
    echo ""
    echo "正在创建 .env 配置文件..."
    cp .env.example .env
    echo "[提示] 请编辑 .env 文件，填入你的私钥"
fi

# 创建config目录（如果不存在）
mkdir -p config

echo ""
echo "========================================"
echo "   安装完成!"
echo "========================================"
echo ""
echo "下一步:"
echo "  1. 编辑 .env 文件，填入你的 BSC 钱包私钥"
echo "  2. 运行 ./start.sh 启动程序"
echo ""
