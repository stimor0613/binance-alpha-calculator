"""
StandX REST API 客户端
实现余额查询、持仓查询、下单、平仓等功能
"""

import json
import requests
from typing import Optional, List
from config import BASE_URL, DEFAULT_TP_PERCENT, DEFAULT_SL_PERCENT
from .auth import StandXAuth


class StandXClient:
    """StandX REST API 客户端"""

    def __init__(self, auth: StandXAuth):
        """
        初始化REST客户端

        Args:
            auth: 认证客户端实例
        """
        self.auth = auth
        self.base_url = BASE_URL

    def _request(self, method: str, endpoint: str, params: dict = None,
                 body: dict = None, need_sign: bool = False) -> dict:
        """
        发送HTTP请求

        Args:
            method: HTTP方法
            endpoint: API端点
            params: 查询参数
            body: 请求体
            need_sign: 是否需要签名

        Returns:
            API响应
        """
        url = f"{self.base_url}{endpoint}"
        headers = self.auth.get_auth_headers()

        # 序列化 body 为紧凑 JSON（无空格）
        body_str = None
        if body:
            body_str = json.dumps(body, separators=(',', ':'))

        # 签名使用相同的 body_str
        if need_sign and body_str:
            sign_headers = self.auth.sign_payload(body_str)
            headers.update(sign_headers)

        # 发送请求，使用 data 确保与签名内容一致
        response = requests.request(
            method=method,
            url=url,
            headers=headers,
            params=params,
            data=body_str
        )
        if not response.ok:
            print(f"[DEBUG] 请求体: {body_str}")
            print(f"[DEBUG] 响应: {response.text}")
        response.raise_for_status()
        return response.json()

    # ==================== 用户端点 ====================

    def get_balance(self) -> dict:
        """
        查询账户余额

        Returns:
            余额信息
        """
        return self._request("GET", "/api/query_balance")

    def get_positions(self, symbol: str = None) -> List[dict]:
        """
        查询当前持仓

        Args:
            symbol: 交易对（可选，不传则查询所有）

        Returns:
            持仓列表
        """
        params = {}
        if symbol:
            params["symbol"] = symbol
        return self._request("GET", "/api/query_positions", params=params)

    def get_position_config(self, symbol: str) -> dict:
        """
        查询仓位配置（杠杆、保证金模式等）

        Args:
            symbol: 交易对

        Returns:
            仓位配置
        """
        return self._request("GET", "/api/query_position_config",
                             params={"symbol": symbol})

    def get_open_orders(self, symbol: str = None) -> List[dict]:
        """
        查询当前挂单

        Args:
            symbol: 交易对（可选）

        Returns:
            挂单列表
        """
        params = {}
        if symbol:
            params["symbol"] = symbol
        return self._request("GET", "/api/query_open_orders", params=params)

    # ==================== 交易端点 ====================

    def create_order(self, symbol: str, side: str, order_type: str,
                     size: float, price: float = None,
                     reduce_only: bool = False,
                     tp_price: float = None, sl_price: float = None,
                     time_in_force: str = "gtc") -> dict:
        """
        创建订单

        Args:
            symbol: 交易对
            side: 方向 (buy/sell)
            order_type: 订单类型 (market/limit)
            size: 数量
            price: 价格（限价单必填）
            reduce_only: 仅减仓
            tp_price: 止盈价格
            sl_price: 止损价格
            time_in_force: 有效期类型 (gtc/ioc/alo)

        Returns:
            订单信息
        """
        body = {
            "symbol": symbol,
            "side": side,
            "order_type": order_type,
            "qty": str(size),
            "reduce_only": reduce_only,
            "time_in_force": time_in_force
        }

        if price and order_type == "limit":
            body["price"] = str(price)

        if tp_price:
            body["tp_price"] = str(tp_price)

        if sl_price:
            body["sl_price"] = str(sl_price)

        return self._request("POST", "/api/new_order", body=body, need_sign=True)

    def _round_price(self, price: float, tick_size: float = 0.01) -> float:
        """
        按照 tick size 格式化价格

        Args:
            price: 原始价格
            tick_size: 价格最小变动单位

        Returns:
            格式化后的价格
        """
        # 使用 round 两次避免浮点数精度问题
        # 例如: round(86490.0 / 0.01) * 0.01 = 86489.99999999999
        # 修复: round(round(86490.0 / 0.01) * 0.01, 2) = 86490.0
        decimals = len(str(tick_size).split('.')[-1]) if '.' in str(tick_size) else 0
        return round(round(price / tick_size) * tick_size, decimals)

    def market_long(self, symbol: str, size: float,
                    tp_percent: float = DEFAULT_TP_PERCENT,
                    sl_percent: float = DEFAULT_SL_PERCENT,
                    current_price: float = None) -> dict:
        """
        市价开多单（带止盈止损）

        Args:
            symbol: 交易对
            size: 数量
            tp_percent: 止盈百分比（默认7%）
            sl_percent: 止损百分比（默认7%）
            current_price: 当前价格（用于计算止盈止损）

        Returns:
            订单信息
        """
        tp_price = None
        sl_price = None

        if current_price:
            # 按 tick size 格式化价格 (BTC-USD tick size = 0.01)
            tp_price = self._round_price(current_price * (1 + tp_percent / 100))
            sl_price = self._round_price(current_price * (1 - sl_percent / 100))

        return self.create_order(
            symbol=symbol,
            side="buy",
            order_type="market",
            size=size,
            tp_price=tp_price,
            sl_price=sl_price
        )

    def market_short(self, symbol: str, size: float,
                     tp_percent: float = DEFAULT_TP_PERCENT,
                     sl_percent: float = DEFAULT_SL_PERCENT,
                     current_price: float = None) -> dict:
        """
        市价开空单（带止盈止损）

        Args:
            symbol: 交易对
            size: 数量
            tp_percent: 止盈百分比（默认7%）
            sl_percent: 止损百分比（默认7%）
            current_price: 当前价格（用于计算止盈止损）

        Returns:
            订单信息
        """
        tp_price = None
        sl_price = None

        if current_price:
            # 空单止盈在下方，止损在上方
            # 按 tick size 格式化价格
            tp_price = self._round_price(current_price * (1 - tp_percent / 100))
            sl_price = self._round_price(current_price * (1 + sl_percent / 100))

        return self.create_order(
            symbol=symbol,
            side="sell",
            order_type="market",
            size=size,
            tp_price=tp_price,
            sl_price=sl_price
        )

    def limit_long(self, symbol: str, size: float, price: float = None,
                   post_only: bool = True) -> tuple[dict, float]:
        """
        限价开多单

        Args:
            symbol: 交易对
            size: 数量
            price: 限价价格（不传则自动获取买1价）
            post_only: 是否只做Maker（默认True，使用alo模式）

        Returns:
            (订单信息, 挂单价格)
        """
        # 如果未指定价格，自动获取买1价
        # 注意：API返回的bids是从低到高排序，买1价是最后一个
        if price is None:
            depth = self.get_depth_book(symbol, limit=100)
            bids = depth.get("bids", [])
            if not bids:
                raise ValueError("无法获取买1价格")
            price = float(bids[-1][0])  # 取最后一个（最高买价）

        # 按 tick size 格式化价格
        price = self._round_price(price)

        result = self.create_order(
            symbol=symbol,
            side="buy",
            order_type="limit",
            size=size,
            price=price,
            time_in_force="alo" if post_only else "gtc"
        )
        return result, price

    def limit_short(self, symbol: str, size: float, price: float = None,
                    post_only: bool = True) -> tuple[dict, float]:
        """
        限价开空单

        Args:
            symbol: 交易对
            size: 数量
            price: 限价价格（不传则自动获取卖1价）
            post_only: 是否只做Maker（默认True，使用alo模式）

        Returns:
            (订单信息, 挂单价格)
        """
        # 如果未指定价格，自动获取卖1价
        # 注意：API返回的asks是从低到高排序，卖1价是第一个（最低卖价）
        if price is None:
            depth = self.get_depth_book(symbol, limit=1)
            asks = depth.get("asks", [])
            if not asks:
                raise ValueError("无法获取卖1价格")
            price = float(asks[0][0])  # 取第一个（最低卖价）

        # 按 tick size 格式化价格
        price = self._round_price(price)

        result = self.create_order(
            symbol=symbol,
            side="sell",
            order_type="limit",
            size=size,
            price=price,
            time_in_force="alo" if post_only else "gtc"
        )
        return result, price

    def close_position(self, symbol: str) -> Optional[dict]:
        """
        一键平仓 - 获取当前仓位，使用仅减仓下单

        Args:
            symbol: 交易对

        Returns:
            订单信息，无仓位返回None
        """
        # 查询当前持仓
        positions = self.get_positions(symbol)

        if not positions:
            return None

        # 处理响应格式
        data = positions.get("data", positions) if isinstance(positions, dict) else positions

        if not isinstance(data, list) or len(data) == 0:
            return None

        # 找到对应symbol的仓位
        position = None
        for pos in data:
            if pos.get("symbol") == symbol:
                position = pos
                break

        if not position:
            return None

        # 获取仓位信息 (API返回字段是 qty)
        qty = float(position.get("qty", 0))
        if qty == 0:
            return None

        # 判断仓位方向并下反向单
        # 如果是多仓(qty > 0)，下卖单平仓
        # 如果是空仓(qty < 0)，下买单平仓
        close_side = "sell" if qty > 0 else "buy"

        return self.create_order(
            symbol=symbol,
            side=close_side,
            order_type="market",
            size=abs(qty),
            reduce_only=True
        )

    def cancel_order(self, order_id: int = None, client_order_id: str = None) -> dict:
        """
        取消订单

        Args:
            order_id: 订单ID (整数类型)
            client_order_id: 客户端订单ID

        Returns:
            取消结果
        """
        body = {}
        if order_id is not None:
            body["order_id"] = int(order_id)  # API 要求 order_id 是整数类型
        if client_order_id:
            body["cl_ord_id"] = client_order_id

        return self._request("POST", "/api/cancel_order", body=body, need_sign=True)

    def cancel_all_orders(self, symbol: str = None) -> list:
        """
        取消所有委托订单

        Args:
            symbol: 交易对（可选，不传则取消所有）

        Returns:
            取消结果列表
        """
        # 获取所有挂单
        response = self.get_open_orders(symbol)

        # 处理响应格式: {"code": 0, "result": [...]}
        if isinstance(response, dict):
            orders = response.get("result", response.get("data", []))
        else:
            orders = response

        if not orders or not isinstance(orders, list):
            return []

        results = []
        for order in orders:
            # 订单ID字段是 "id"，类型是整数
            order_id = order.get("id") or order.get("order_id") or order.get("orderId")
            if order_id:
                try:
                    result = self.cancel_order(order_id=int(order_id))
                    results.append({"order_id": order_id, "status": "success", "result": result})
                except Exception as e:
                    results.append({"order_id": order_id, "status": "failed", "error": str(e)})

        return results

    def change_leverage(self, symbol: str, leverage: int) -> dict:
        """
        修改杠杆倍数

        Args:
            symbol: 交易对
            leverage: 杠杆倍数

        Returns:
            修改结果
        """
        body = {
            "symbol": symbol,
            "leverage": leverage
        }
        return self._request("POST", "/api/change_leverage", body=body, need_sign=True)

    # ==================== 公共端点 ====================

    def get_symbol_info(self, symbol: str) -> dict:
        """
        查询交易对信息

        Args:
            symbol: 交易对

        Returns:
            交易对信息
        """
        return self._request("GET", "/api/query_symbol_info",
                             params={"symbol": symbol})

    def get_symbol_price(self, symbol: str) -> dict:
        """
        查询当前价格

        Args:
            symbol: 交易对

        Returns:
            价格信息
        """
        return self._request("GET", "/api/query_symbol_price",
                             params={"symbol": symbol})

    def get_depth_book(self, symbol: str, limit: int = 20) -> dict:
        """
        查询深度数据

        Args:
            symbol: 交易对
            limit: 档位数量

        Returns:
            深度数据
        """
        return self._request("GET", "/api/query_depth_book",
                             params={"symbol": symbol, "limit": limit})
