"""
StandX 认证模块
使用钱包签名进行身份验证，获取JWT Token
支持 BSC 链 (EVM)
"""

import os
import time
import uuid
import json
import base64
import requests
import base58
from eth_account import Account
from eth_account.messages import encode_defunct
from nacl.signing import SigningKey

from config import AUTH_URL


def decode_jwt_payload(jwt_token: str) -> dict:
    """解码JWT的payload部分"""
    parts = jwt_token.split('.')
    if len(parts) != 3:
        raise ValueError("Invalid JWT format")

    # 解码payload（第二部分）
    payload_b64 = parts[1]
    # 添加padding
    padding = 4 - len(payload_b64) % 4
    if padding != 4:
        payload_b64 += '=' * padding

    payload_json = base64.urlsafe_b64decode(payload_b64)
    return json.loads(payload_json)


class StandXAuth:
    """StandX 认证客户端 (BSC链)"""

    def __init__(self, private_key: str, chain: str = "bsc", ed25519_key: str = None):
        """
        初始化认证客户端

        Args:
            private_key: BSC私钥 (0x开头的十六进制格式)
            chain: 链类型 (bsc)
            ed25519_key: Ed25519私钥 (hex格式，用于交易签名)
        """
        self.chain = chain
        self.base_url = AUTH_URL
        self.token = None
        self.token_expires_at = 0

        # 解析BSC私钥
        if not private_key.startswith("0x"):
            private_key = "0x" + private_key

        self.account = Account.from_key(private_key)
        self.address = self.account.address

        # 初始化Ed25519签名密钥
        if ed25519_key:
            self.signing_key = SigningKey(bytes.fromhex(ed25519_key))
        else:
            # 如果没有提供，生成新的密钥对并自动保存到.env
            self.signing_key = SigningKey.generate()
            new_key = self.signing_key.encode().hex()
            print(f"[信息] 已生成新的 ED25519_KEY 并保存到 .env 文件")
            self._save_ed25519_key_to_env(new_key)

        # Base58编码的公钥用于requestId
        self.ed25519_public_key = base58.b58encode(
            self.signing_key.verify_key.encode()
        ).decode()

    def _save_ed25519_key_to_env(self, key: str):
        """保存 ED25519_KEY 到 .env 文件"""
        env_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), '.env')

        # 读取现有内容
        lines = []
        key_exists = False
        if os.path.exists(env_path):
            with open(env_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()

            # 检查是否已有 ED25519_KEY
            for i, line in enumerate(lines):
                if line.startswith('ED25519_KEY='):
                    lines[i] = f'ED25519_KEY={key}\n'
                    key_exists = True
                    break

        if not key_exists:
            lines.append(f'ED25519_KEY={key}\n')

        # 写回文件
        with open(env_path, 'w', encoding='utf-8') as f:
            f.writelines(lines)

    def _sign_message(self, message: str) -> str:
        """签名消息 (EIP-191 personal_sign)"""
        message_encoded = encode_defunct(text=message)
        signed = self.account.sign_message(message_encoded)
        # 返回带0x前缀的十六进制签名
        sig_hex = signed.signature.hex()
        if not sig_hex.startswith("0x"):
            sig_hex = "0x" + sig_hex
        return sig_hex

    def prepare_signin(self) -> dict:
        """
        准备签名登录

        Returns:
            包含signedData的响应
        """
        url = f"{self.base_url}/v1/offchain/prepare-signin"

        # 使用Base58编码的Ed25519公钥作为requestId
        payload = {
            "address": self.address,
            "requestId": self.ed25519_public_key
        }

        response = requests.post(
            url,
            params={"chain": self.chain},
            json=payload
        )
        response.raise_for_status()
        return response.json()

    def login(self, expires_seconds: int = 604800) -> str:
        """
        登录获取Token

        Args:
            expires_seconds: Token有效期（秒），默认7天

        Returns:
            JWT Token
        """
        # 1. 准备签名
        prepare_result = self.prepare_signin()
        signed_data = prepare_result.get("signedData")

        if not signed_data:
            raise Exception("Failed to get signedData from prepare-signin")

        # 2. 解码JWT获取message字段并签名
        jwt_payload = decode_jwt_payload(signed_data)
        message_to_sign = jwt_payload.get("message")

        if not message_to_sign:
            raise Exception("Failed to get message from JWT payload")

        # 3. 签名message
        signature = self._sign_message(message_to_sign)

        # 4. 登录
        url = f"{self.base_url}/v1/offchain/login"
        payload = {
            "signature": signature,
            "signedData": signed_data,
            "expiresSeconds": expires_seconds
        }

        response = requests.post(
            url,
            params={"chain": self.chain},
            json=payload
        )
        if not response.ok:
            print(f"[DEBUG] Login status: {response.status_code}")
            print(f"[DEBUG] Login response: {response.text}")
        response.raise_for_status()
        result = response.json()

        self.token = result.get("token")
        # 设置过期时间（提前5分钟刷新）
        self.token_expires_at = time.time() + expires_seconds - 300


        return self.token

    def get_token(self) -> str:
        """
        获取有效的Token，如果过期则自动刷新

        Returns:
            JWT Token
        """
        if not self.token or time.time() >= self.token_expires_at:
            self.login()
        return self.token

    def get_auth_headers(self) -> dict:
        """
        获取带认证的请求头

        Returns:
            包含Authorization的请求头
        """
        return {
            "Authorization": f"Bearer {self.get_token()}",
            "Content-Type": "application/json"
        }

    def sign_payload(self, payload_str: str) -> dict:
        """
        签名已序列化的 JSON 字符串

        Args:
            payload_str: 已序列化的 JSON 字符串

        Returns:
            签名相关的 headers
        """
        version = "v1"
        request_id = str(uuid.uuid4())
        timestamp = int(time.time() * 1000)

        # 构建签名消息: "{version},{id},{timestamp},{payload}"
        sign_message = f"{version},{request_id},{timestamp},{payload_str}"

        # Ed25519 签名
        message_bytes = sign_message.encode('utf-8')
        signed = self.signing_key.sign(message_bytes)
        signature = base64.b64encode(signed.signature).decode()

        return {
            "x-request-sign-version": version,
            "x-request-id": request_id,
            "x-request-timestamp": str(timestamp),
            "x-request-signature": signature
        }
