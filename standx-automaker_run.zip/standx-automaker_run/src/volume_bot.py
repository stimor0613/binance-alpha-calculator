"""
限市刷量机器人
开仓：限价单（PostOnly）同时挂多单和空单
平仓：市价单快速平仓
"""

import asyncio
from enum import Enum
from typing import Optional
from .rest_client import StandXClient
from config import MIN_POSITION_THRESHOLD


class BotState(Enum):
    """机器人状态"""
    IDLE = "空闲"
    OPENING = "开仓中"
    CLOSING = "平仓中"
    STOPPED = "已停止"


class LimitMarketVolumeBot:
    """限市刷量机器人"""

    def __init__(self, client: StandXClient, symbol: str, order_amount: float):
        """
        初始化刷量机器人

        Args:
            client: REST API 客户端
            symbol: 交易对 (如 BTC-USD)
            order_amount: 每次下单数量
        """
        self.client = client
        self.symbol = symbol
        self.order_amount = order_amount
        # 仓位阈值从配置文件读取
        self.position_threshold = MIN_POSITION_THRESHOLD

        # 状态
        self.state = BotState.IDLE
        self.running = False

        # 统计
        self.round_count = 0
        self.total_volume = 0.0

        # 挂单价格记录（用于监控价格变化）
        self.order_price_long: Optional[float] = None
        self.order_price_short: Optional[float] = None

    def _get_bid_ask(self) -> tuple:
        """获取买1价和卖1价"""
        depth = self.client.get_depth_book(self.symbol, limit=100)
        bids = depth.get("bids", [])
        asks = depth.get("asks", [])

        bid = float(bids[-1][0]) if bids else None  # 买1价（最高买价）
        ask = float(asks[0][0]) if asks else None   # 卖1价（最低卖价）

        return bid, ask

    def _get_position(self) -> float:
        """获取当前持仓数量，正数=多仓，负数=空仓"""
        positions = self.client.get_positions(self.symbol)
        data = positions.get("data", positions) if isinstance(positions, dict) else positions

        if isinstance(data, list):
            for pos in data:
                if pos.get("symbol") == self.symbol:
                    return float(pos.get("qty", 0))
        return 0.0

    def _get_open_orders_count(self) -> int:
        """获取当前挂单数量"""
        response = self.client.get_open_orders(self.symbol)
        if isinstance(response, dict):
            orders = response.get("result", response.get("data", []))
        else:
            orders = response
        return len(orders) if orders else 0

    async def _open_position_flow(self) -> bool:
        """
        开仓流程

        Returns:
            bool: True=开仓成功，切换到平仓流程
                  False=继续开仓流程（重试）
        """
        self.state = BotState.OPENING
        print(f"\n[开仓流程] 开始第 {self.round_count + 1} 轮")

        # 步骤1: 取消所有委托
        print("  取消所有委托...")
        self.client.cancel_all_orders(self.symbol)
        await asyncio.sleep(0.1)

        # 步骤2: 获取价格和持仓
        bid, ask = self._get_bid_ask()
        if bid is None or ask is None:
            print("  无法获取价格，重试...")
            await asyncio.sleep(0.3)
            return False

        position = self._get_position()
        position_qty = abs(position)
        print(f"  持仓检查: {position_qty:.6f}")

        # 步骤3: 判断是否需要平仓
        if position_qty >= self.position_threshold:
            print(f"  仓位 >= {self.position_threshold}，切换到平仓流程")
            return True

        # 步骤4: 确定下单价格
        long_price = bid
        short_price = ask

        print(f"  下多单: {self.order_amount} @ {long_price:.2f}")
        print(f"  下空单: {self.order_amount} @ {short_price:.2f}")

        # 步骤5: 下多单和空单
        try:
            long_result, _ = self.client.limit_long(
                symbol=self.symbol,
                size=self.order_amount,
                price=long_price,
                post_only=True
            )
        except Exception as e:
            print(f"  多单下单失败: {e}")
            await asyncio.sleep(0.3)
            return False

        try:
            short_result, _ = self.client.limit_short(
                symbol=self.symbol,
                size=self.order_amount,
                price=short_price,
                post_only=True
            )
        except Exception as e:
            print(f"  空单下单失败: {e}")
            await asyncio.sleep(0.3)
            return False

        # 记录原始市场价格
        self.order_price_long = bid
        self.order_price_short = ask

        # 步骤7: 等待订单上链
        await asyncio.sleep(0.3)

        # 步骤8: 判断真假委托
        orders_count = self._get_open_orders_count()

        if orders_count < 2:
            print(f"  假委托（订单数: {orders_count}），重新开仓...")
            return False

        print(f"  真委托确认，订单数: {orders_count}")

        # 步骤9: 监控价格和持仓变化
        return await self._monitor_open_position()

    async def _monitor_open_position(self) -> bool:
        """
        监控开仓状态

        Returns:
            bool: True=开仓成功，切换到平仓
                  False=需要重新开仓
        """
        print("  监控中...")

        while self.running and self.state == BotState.OPENING:
            bid, ask = self._get_bid_ask()
            if bid is None or ask is None:
                await asyncio.sleep(0.1)
                continue

            # 检查价格是否变化
            price_changed = False

            if self.order_price_long and abs(bid - self.order_price_long) > 0.1:
                print(f"  买1价变化: {self.order_price_long:.2f} -> {bid:.2f}，重新开仓")
                price_changed = True

            if self.order_price_short and abs(ask - self.order_price_short) > 0.1:
                print(f"  卖1价变化: {self.order_price_short:.2f} -> {ask:.2f}，重新开仓")
                price_changed = True

            if price_changed:
                return False

            # 检查持仓是否建立
            position = self._get_position()
            position_qty = abs(position)

            if position_qty >= self.position_threshold:
                print(f"  开仓成功! 持仓数量: {position_qty:.6f}")
                self.total_volume += self.order_amount
                return True

            await asyncio.sleep(0.1)

        return False

    async def _close_position_flow(self) -> bool:
        """
        平仓流程（市价平仓）

        Returns:
            bool: True=平仓成功，切换到开仓流程
                  False=继续平仓流程（重试）
        """
        self.state = BotState.CLOSING
        print(f"\n[平仓流程] 第 {self.round_count + 1} 轮")

        # 步骤1: 取消所有委托
        print("  取消所有委托...")
        self.client.cancel_all_orders(self.symbol)
        await asyncio.sleep(0.1)

        # 步骤2: 获取持仓
        position = self._get_position()
        position_qty = abs(position)
        print(f"  持仓检查: {position_qty:.6f}")

        # 步骤3: 判断是否需要开仓
        if position_qty < self.position_threshold:
            print(f"  仓位 < {self.position_threshold}，切换到开仓流程")
            return True

        # 步骤4: 市价平仓
        close_amount = abs(position)

        if position > 0:
            print(f"  市价平多仓: 卖出 {close_amount:.6f}")
        else:
            print(f"  市价平空仓: 买入 {close_amount:.6f}")

        try:
            result = self.client.close_position(self.symbol)
            if not result:
                print("  市价平仓失败: 无持仓")
                await asyncio.sleep(0.3)
                return False
        except Exception as e:
            print(f"  市价平仓失败: {e}")
            await asyncio.sleep(0.3)
            return False

        # 步骤5: 平仓成功
        print(f"  市价平仓成功!")
        self.total_volume += close_amount

        return True

    async def _main_loop(self):
        """主循环"""
        in_opening_flow = True

        while self.running:
            try:
                if in_opening_flow:
                    switch_to_close = await self._open_position_flow()
                    if switch_to_close:
                        in_opening_flow = False
                else:
                    switch_to_open = await self._close_position_flow()
                    if switch_to_open:
                        in_opening_flow = True
                        self.round_count += 1

            except Exception as e:
                print(f"主循环错误: {e}")
                await asyncio.sleep(1)

    async def start(self):
        """启动刷量机器人"""
        print("=" * 60)
        print("  [刷量模式] 作者：岳来岳会赚")
        print("  Twitter: @188888_x  TG: @Pacemak1r_8")
        print("  注册立享5%积分加成: standx.com/referral?code=YP9993")
        print("=" * 60)
        print(f"  产品: {self.symbol} | 数量: {self.order_amount}")

        self.running = True
        self.state = BotState.IDLE
        self.round_count = 0
        self.total_volume = 0.0

        await self._main_loop()

    async def stop(self):
        """停止刷量机器人"""
        self.running = False
        self.state = BotState.STOPPED

        # 取消所有未成交的委托
        print("\n正在取消所有委托...")
        try:
            self.client.cancel_all_orders(self.symbol)
        except Exception as e:
            print(f"取消委托失败: {e}")

        # 打印统计
        print(f"\n{'='*50}")
        print(f"  刷量机器人已停止")
        print(f"  完成轮数: {self.round_count}")
        print(f"  总成交量: {self.total_volume:.6f}")
        print(f"{'='*50}")
