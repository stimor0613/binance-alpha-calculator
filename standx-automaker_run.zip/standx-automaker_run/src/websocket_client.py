"""
StandX WebSocket 客户端
实时价格订阅和持仓订阅，支持自动重连和官网心跳方式
"""

import json
import asyncio
import uuid
import websockets
from typing import Callable, Optional, TYPE_CHECKING
from config import WS_STREAM_URL, WS_API_URL

if TYPE_CHECKING:
    from .auth import StandXAuth


class PriceWebSocket:
    """
    实时价格WebSocket客户端

    特性：
    - 订阅买卖1价格
    - 断开后立即自动重连
    - 按官网API方式响应服务器Ping（服务器每10秒发送Ping）
    """

    def __init__(self, symbol: str, on_price_update: Callable[[dict], None]):
        """
        初始化WebSocket客户端

        Args:
            symbol: 交易对 (如 BTC-USD)
            on_price_update: 价格更新回调函数
        """
        self.symbol = symbol
        self.on_price_update = on_price_update
        self.ws_url = WS_STREAM_URL
        self.ws: Optional[websockets.WebSocketClientProtocol] = None
        self.running = False
        self.current_price = {
            "bid": None,  # 买1价
            "ask": None,  # 卖1价
            "last": None  # 最新价
        }

    async def connect(self):
        """建立WebSocket连接"""
        while self.running:
            try:
                print(f"[WS] 正在连接 {self.symbol}...")
                async with websockets.connect(
                    self.ws_url,
                    ping_interval=None,  # 禁用客户端ping，由服务器控制
                    ping_timeout=None
                ) as ws:
                    self.ws = ws
                    print(f"[WS] 已连接，订阅 {self.symbol} 价格...")

                    # 订阅价格频道
                    subscribe_msg = {
                        "subscribe": {
                            "channel": "price",
                            "symbol": self.symbol
                        }
                    }
                    await ws.send(json.dumps(subscribe_msg))

                    # 同时订阅深度数据获取买卖1
                    depth_subscribe_msg = {
                        "subscribe": {
                            "channel": "depth_book",
                            "symbol": self.symbol
                        }
                    }
                    await ws.send(json.dumps(depth_subscribe_msg))

                    # 接收消息循环
                    async for message in ws:
                        await self._handle_message(message)

            except websockets.ConnectionClosed as e:
                print(f"[WS] 连接关闭: {e}, 立即重连...")
            except Exception as e:
                print(f"[WS] 连接错误: {e}, 立即重连...")

            # 立即重连（不等待）
            if self.running:
                await asyncio.sleep(0.1)  # 极短延迟防止CPU占用过高

    async def _handle_message(self, message: str):
        """处理接收到的消息"""
        try:
            # 处理Ping消息（按官网方式：服务器发送WebSocket Ping帧）
            # websockets库会自动响应Ping帧，这里处理可能的文本ping
            if message == "ping":
                await self.ws.send("pong")
                return

            data = json.loads(message)
            channel = data.get("channel")

            if channel == "price":
                # 价格数据
                price_data = data.get("data", {})
                self.current_price["last"] = price_data.get("last_price")
                self.current_price["index"] = price_data.get("index_price")
                self.current_price["mark"] = price_data.get("mark_price")
                self._notify_price_update()

            elif channel == "depth_book":
                # 深度数据 - 获取买卖1
                depth_data = data.get("data", {})
                bids = depth_data.get("bids", [])
                asks = depth_data.get("asks", [])

                if bids:
                    self.current_price["bid"] = float(bids[0][0])  # 买1价
                if asks:
                    self.current_price["ask"] = float(asks[0][0])  # 卖1价

                self._notify_price_update()

        except json.JSONDecodeError:
            pass
        except Exception as e:
            print(f"[WS] 处理消息错误: {e}")

    def _notify_price_update(self):
        """通知价格更新"""
        if self.on_price_update:
            self.on_price_update(self.current_price.copy())

    async def start(self):
        """启动WebSocket连接"""
        self.running = True
        await self.connect()

    async def stop(self):
        """停止WebSocket连接"""
        self.running = False
        if self.ws:
            await self.ws.close()

    def change_symbol(self, new_symbol: str):
        """
        切换交易对

        Args:
            new_symbol: 新的交易对
        """
        self.symbol = new_symbol
        self.current_price = {"bid": None, "ask": None, "last": None}
        # 重新连接会自动订阅新的symbol


class PriceManager:
    """价格管理器 - 管理WebSocket连接"""

    def __init__(self):
        self.ws_client: Optional[PriceWebSocket] = None
        self.current_symbol = "BTC-USD"
        self.latest_price = {}
        self._task: Optional[asyncio.Task] = None

    def _on_price_update(self, price: dict):
        """价格更新回调"""
        self.latest_price = price

    async def start(self, symbol: str = "BTC-USD"):
        """启动价格订阅"""
        self.current_symbol = symbol
        self.ws_client = PriceWebSocket(symbol, self._on_price_update)
        self._task = asyncio.create_task(self.ws_client.start())

    async def stop(self):
        """停止价格订阅"""
        if self.ws_client:
            await self.ws_client.stop()
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

    async def change_symbol(self, symbol: str):
        """切换交易对"""
        await self.stop()
        await self.start(symbol)

    def get_price(self) -> dict:
        """获取当前价格"""
        return self.latest_price.copy()

    def get_bid_ask(self) -> tuple:
        """获取买卖1价格"""
        return (
            self.latest_price.get("bid"),
            self.latest_price.get("ask")
        )


class PositionWebSocket:
    """
    实时持仓WebSocket客户端

    特性：
    - 订阅持仓更新（需要认证）
    - 断开后立即自动重连
    - 按官网API方式响应服务器Ping
    """

    def __init__(self, auth: "StandXAuth", on_position_update: Callable[[dict], None]):
        """
        初始化WebSocket客户端

        Args:
            auth: 认证客户端实例
            on_position_update: 持仓更新回调函数
        """
        self.auth = auth
        self.on_position_update = on_position_update
        self.ws_url = WS_STREAM_URL  # 私有频道也使用 ws-stream，但需要先认证
        self.ws: Optional[websockets.WebSocketClientProtocol] = None
        self.running = False
        self.current_position = {}

    async def connect(self):
        """建立WebSocket连接"""
        while self.running:
            try:
                # 获取JWT token用于认证
                token = self.auth.get_token()

                print(f"[WS-Position] 正在连接...")
                async with websockets.connect(
                    self.ws_url,
                    ping_interval=None,
                    ping_timeout=None
                ) as ws:
                    self.ws = ws
                    print(f"[WS-Position] 已连接")

                    # 先发送认证消息
                    print("[WS-Position] 发送认证...")
                    auth_msg = {
                        "auth": {
                            "token": token,
                            "streams": [{"channel": "position"}]
                        }
                    }
                    await ws.send(json.dumps(auth_msg))

                    # 然后订阅持仓频道
                    print("[WS-Position] 订阅持仓频道...")
                    subscribe_msg = {
                        "subscribe": {
                            "channel": "position"
                        }
                    }
                    await ws.send(json.dumps(subscribe_msg))

                    # 接收消息循环
                    async for message in ws:
                        await self._handle_message(message)

            except websockets.ConnectionClosed as e:
                print(f"[WS-Position] 连接关闭: {e}, 立即重连...")
            except Exception as e:
                print(f"[WS-Position] 连接错误: {e}, 立即重连...")

            # 立即重连
            if self.running:
                await asyncio.sleep(0.1)

    async def _handle_message(self, message: str):
        """处理接收到的消息"""
        try:
            # 处理Ping消息
            if message == "ping":
                await self.ws.send("pong")
                return

            data = json.loads(message)
            channel = data.get("channel")

            if channel == "position":
                # 持仓数据
                position_data = data.get("data", {})
                self.current_position = position_data
                self._notify_position_update()

        except json.JSONDecodeError:
            pass
        except Exception as e:
            print(f"[WS-Position] 处理消息错误: {e}")

    def _notify_position_update(self):
        """通知持仓更新"""
        if self.on_position_update:
            self.on_position_update(self.current_position.copy())

    async def start(self):
        """启动WebSocket连接"""
        self.running = True
        await self.connect()

    async def stop(self):
        """停止WebSocket连接"""
        self.running = False
        if self.ws:
            await self.ws.close()


class PositionManager:
    """持仓管理器 - 管理持仓WebSocket连接"""

    def __init__(self, auth: "StandXAuth"):
        """
        初始化持仓管理器

        Args:
            auth: 认证客户端实例
        """
        self.auth = auth
        self.ws_client: Optional[PositionWebSocket] = None
        self.latest_position = {}
        self._task: Optional[asyncio.Task] = None
        self._callbacks = []

    def _on_position_update(self, position: dict):
        """持仓更新回调"""
        self.latest_position = position
        # 通知所有注册的回调
        for callback in self._callbacks:
            try:
                callback(position)
            except Exception as e:
                print(f"[PositionManager] 回调错误: {e}")

    def add_callback(self, callback: Callable[[dict], None]):
        """添加持仓更新回调"""
        self._callbacks.append(callback)

    def remove_callback(self, callback: Callable[[dict], None]):
        """移除持仓更新回调"""
        if callback in self._callbacks:
            self._callbacks.remove(callback)

    async def start(self):
        """启动持仓订阅"""
        self.ws_client = PositionWebSocket(self.auth, self._on_position_update)
        self._task = asyncio.create_task(self.ws_client.start())

    async def stop(self):
        """停止持仓订阅"""
        if self.ws_client:
            await self.ws_client.stop()
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

    def get_position(self) -> dict:
        """获取当前持仓"""
        return self.latest_position.copy()

    def get_position_by_symbol(self, symbol: str) -> Optional[dict]:
        """
        获取指定交易对的持仓

        Args:
            symbol: 交易对

        Returns:
            持仓信息，无持仓返回None
        """
        # 如果是单个持仓
        if self.latest_position.get("symbol") == symbol:
            return self.latest_position.copy()

        # 如果是持仓列表
        if isinstance(self.latest_position, list):
            for pos in self.latest_position:
                if pos.get("symbol") == symbol:
                    return pos.copy()

        return None

    def get_position_qty(self, symbol: str) -> float:
        """
        获取指定交易对的持仓数量

        Args:
            symbol: 交易对

        Returns:
            持仓数量，正数为多仓，负数为空仓，0为无持仓
        """
        pos = self.get_position_by_symbol(symbol)
        if pos:
            return float(pos.get("qty", 0))
        return 0.0

    def set_initial_position(self, position: dict):
        """
        设置初始持仓（用于REST API获取的快照）

        Args:
            position: 持仓数据
        """
        self.latest_position = position
        # 也通知回调
        for callback in self._callbacks:
            try:
                callback(position)
            except Exception as e:
                print(f"[PositionManager] 回调错误: {e}")


class OrderWebSocket:
    """
    实时订单WebSocket客户端

    特性：
    - 订阅订单状态更新（需要认证）
    - 断开后立即自动重连
    - 按官网API方式响应服务器Ping
    """

    def __init__(self, auth: "StandXAuth", on_order_update: Callable[[dict], None]):
        """
        初始化WebSocket客户端

        Args:
            auth: 认证客户端实例
            on_order_update: 订单更新回调函数
        """
        self.auth = auth
        self.on_order_update = on_order_update
        self.ws_url = WS_STREAM_URL
        self.ws: Optional[websockets.WebSocketClientProtocol] = None
        self.running = False

    async def connect(self):
        """建立WebSocket连接"""
        while self.running:
            try:
                token = self.auth.get_token()

                print(f"[WS-Order] 正在连接...")
                async with websockets.connect(
                    self.ws_url,
                    ping_interval=None,
                    ping_timeout=None
                ) as ws:
                    self.ws = ws
                    print(f"[WS-Order] 已连接")

                    # 发送认证消息
                    print("[WS-Order] 发送认证...")
                    auth_msg = {
                        "auth": {
                            "token": token,
                            "streams": [{"channel": "order"}]
                        }
                    }
                    await ws.send(json.dumps(auth_msg))

                    # 订阅订单频道
                    print("[WS-Order] 订阅订单频道...")
                    subscribe_msg = {
                        "subscribe": {
                            "channel": "order"
                        }
                    }
                    await ws.send(json.dumps(subscribe_msg))

                    # 接收消息循环
                    async for message in ws:
                        await self._handle_message(message)

            except websockets.ConnectionClosed as e:
                print(f"[WS-Order] 连接关闭: {e}, 立即重连...")
            except Exception as e:
                print(f"[WS-Order] 连接错误: {e}, 立即重连...")

            if self.running:
                await asyncio.sleep(0.1)

    async def _handle_message(self, message: str):
        """处理接收到的消息"""
        try:
            if message == "ping":
                await self.ws.send("pong")
                return

            data = json.loads(message)
            channel = data.get("channel")

            if channel == "order":
                order_data = data.get("data", {})
                if self.on_order_update:
                    self.on_order_update(order_data)

        except json.JSONDecodeError:
            pass
        except Exception as e:
            print(f"[WS-Order] 处理消息错误: {e}")

    async def start(self):
        """启动WebSocket连接"""
        self.running = True
        await self.connect()

    async def stop(self):
        """停止WebSocket连接"""
        self.running = False
        if self.ws:
            await self.ws.close()


class OrderManager:
    """订单管理器 - 管理订单WebSocket连接"""

    def __init__(self, auth: "StandXAuth"):
        """
        初始化订单管理器

        Args:
            auth: 认证客户端实例
        """
        self.auth = auth
        self.ws_client: Optional[OrderWebSocket] = None
        self.orders = {}  # order_id -> order_data
        self._task: Optional[asyncio.Task] = None
        self._callbacks = []

    def _on_order_update(self, order: dict):
        """订单更新回调"""
        order_id = order.get("id")
        if order_id:
            self.orders[order_id] = order
        # 通知所有注册的回调
        for callback in self._callbacks:
            try:
                callback(order)
            except Exception as e:
                print(f"[OrderManager] 回调错误: {e}")

    def add_callback(self, callback: Callable[[dict], None]):
        """添加订单更新回调"""
        self._callbacks.append(callback)

    def remove_callback(self, callback: Callable[[dict], None]):
        """移除订单更新回调"""
        if callback in self._callbacks:
            self._callbacks.remove(callback)

    async def start(self):
        """启动订单订阅"""
        self.ws_client = OrderWebSocket(self.auth, self._on_order_update)
        self._task = asyncio.create_task(self.ws_client.start())

    async def stop(self):
        """停止订单订阅"""
        if self.ws_client:
            await self.ws_client.stop()
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass

    def get_order(self, order_id: int) -> Optional[dict]:
        """获取指定订单"""
        return self.orders.get(order_id)

    def get_all_orders(self) -> dict:
        """获取所有订单"""
        return self.orders.copy()
