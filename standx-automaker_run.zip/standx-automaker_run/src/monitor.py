#!/usr/bin/env python3
"""
StandX Maker Bot 心跳监控脚本
检测心跳文件，超时则发送 Discord/飞书 告警

作者：岳来岳会赚
Twitter: @188888_x  TG: @Pacemak1r_8
"""

import os
import time
import requests
from pathlib import Path
from dotenv import load_dotenv

# 加载 .env 配置 (从项目根目录)
env_path = Path(__file__).parent.parent / ".env"
load_dotenv(env_path)

# ============== 配置 ==============
TIMEOUT = 15          # 心跳超时时间（秒）
CHECK_INTERVAL = 10   # 检查间隔（秒）

# Webhook 配置（从 .env 读取）
DISCORD_WEBHOOK = os.getenv("DISCORD_WEBHOOK", "")
FEISHU_WEBHOOK = os.getenv("FEISHU_WEBHOOK", "")

# 心跳文件路径 (在项目根目录)
SCRIPT_DIR = Path(__file__).parent.parent
HEARTBEAT_FILE = SCRIPT_DIR / "heartbeat.txt"


class Monitor:
    """心跳监控器"""

    def __init__(self):
        self.alert_sent = False

    def send_discord(self, title: str, message: str, color: int = 0xFF0000) -> bool:
        """发送 Discord 通知"""
        if not DISCORD_WEBHOOK:
            return False

        try:
            payload = {
                "embeds": [{
                    "title": title,
                    "description": message,
                    "color": color,
                    "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
                }]
            }
            resp = requests.post(DISCORD_WEBHOOK, json=payload, timeout=10)
            return resp.status_code == 204
        except Exception as e:
            print(f"[Discord] 发送失败: {e}")
            return False

    def send_feishu(self, title: str, message: str) -> bool:
        """发送飞书通知"""
        if not FEISHU_WEBHOOK:
            return False

        try:
            payload = {
                "msg_type": "post",
                "content": {
                    "post": {
                        "zh_cn": {
                            "title": title,
                            "content": [[
                                {"tag": "text", "text": message}
                            ]]
                        }
                    }
                }
            }
            resp = requests.post(FEISHU_WEBHOOK, json=payload, timeout=10)
            return resp.status_code == 200
        except Exception as e:
            print(f"[飞书] 发送失败: {e}")
            return False

    def send_alert(self, title: str, message: str, color: int = 0xFF0000):
        """发送告警到所有渠道"""
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"[{timestamp}] {title}: {message}")

        self.send_discord(title, message, color)
        self.send_feishu(title, message)

    def check_heartbeat(self) -> bool:
        """检查心跳文件"""
        # 检查文件是否存在
        if not HEARTBEAT_FILE.exists():
            if not self.alert_sent:
                self.send_alert(
                    "⚠️ StandX Bot 告警",
                    "心跳文件不存在，机器人可能未启动",
                    0xFF0000
                )
                self.alert_sent = True
            return False

        try:
            # 读取心跳文件
            with open(HEARTBEAT_FILE, "r") as f:
                lines = f.readlines()

            if len(lines) < 5:
                return False

            last_heartbeat = int(lines[0].strip())
            symbol = lines[1].strip()
            mark_price = lines[2].strip()
            position = lines[3].strip()
            state = lines[4].strip()

            # 计算超时
            current_time = int(time.time())
            diff = current_time - last_heartbeat

            if diff > TIMEOUT:
                if not self.alert_sent:
                    self.send_alert(
                        "⚠️ StandX Bot 告警",
                        f"心跳超时 {diff}秒！\n"
                        f"币种: {symbol}\n"
                        f"最后价格: ${mark_price}\n"
                        f"状态: {state}",
                        0xFF0000
                    )
                    self.alert_sent = True
                return False
            else:
                # 心跳正常，重置告警状态
                if self.alert_sent:
                    self.send_alert(
                        "✅ StandX Bot 恢复",
                        f"机器人已恢复正常运行\n"
                        f"币种: {symbol}\n"
                        f"当前价格: ${mark_price}",
                        0x00FF00
                    )
                    self.alert_sent = False
                return True

        except Exception as e:
            print(f"[错误] 读取心跳文件失败: {e}")
            return False

    def run(self):
        """运行监控"""
        print("=" * 60)
        print("  StandX Bot 心跳监控")
        print("  作者：岳来岳会赚")
        print("  注册立享5%积分加成: standx.com/referral?code=YP9993")
        print("=" * 60)
        print(f"心跳文件: {HEARTBEAT_FILE}")
        print(f"超时时间: {TIMEOUT}秒")
        print(f"检查间隔: {CHECK_INTERVAL}秒")
        print(f"Discord: {'已配置' if DISCORD_WEBHOOK else '未配置'}")
        print(f"飞书: {'已配置' if FEISHU_WEBHOOK else '未配置'}")
        print("=" * 50)
        print("")

        # 启动通知
        self.send_alert(
            "✅ StandX 监控启动",
            f"心跳监控已启动，超时阈值: {TIMEOUT}秒",
            0x00FF00
        )

        # 主循环
        while True:
            self.check_heartbeat()
            time.sleep(CHECK_INTERVAL)


if __name__ == "__main__":
    try:
        monitor = Monitor()
        monitor.run()
    except KeyboardInterrupt:
        print("\n监控已停止")
