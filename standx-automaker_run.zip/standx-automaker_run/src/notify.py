"""
通知模块 - 发送 Discord/飞书 告警

作者：岳来岳会赚
Twitter: @188888_x  TG: @Pacemak1r_8
"""

import os
import time
import requests
from pathlib import Path
from dotenv import load_dotenv

# 加载 .env 配置 (从项目根目录)
env_path = Path(__file__).parent.parent / ".env"
load_dotenv(env_path)

# Webhook 配置（从 .env 读取）
DISCORD_WEBHOOK = os.getenv("DISCORD_WEBHOOK", "")
FEISHU_WEBHOOK = os.getenv("FEISHU_WEBHOOK", "")


def send_discord(title: str, message: str, color: int = 0xFF0000) -> bool:
    """发送 Discord 通知"""
    if not DISCORD_WEBHOOK:
        return False

    try:
        payload = {
            "embeds": [{
                "title": title,
                "description": message,
                "color": color,
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            }]
        }
        resp = requests.post(DISCORD_WEBHOOK, json=payload, timeout=10)
        return resp.status_code == 204
    except Exception as e:
        print(f"[Discord] 发送失败: {e}")
        return False


def send_feishu(title: str, message: str) -> bool:
    """发送飞书通知"""
    if not FEISHU_WEBHOOK:
        return False

    try:
        payload = {
            "msg_type": "post",
            "content": {
                "post": {
                    "zh_cn": {
                        "title": title,
                        "content": [[
                            {"tag": "text", "text": message}
                        ]]
                    }
                }
            }
        }
        resp = requests.post(FEISHU_WEBHOOK, json=payload, timeout=10)
        return resp.status_code == 200
    except Exception as e:
        print(f"[飞书] 发送失败: {e}")
        return False


def send_alert(title: str, message: str, color: int = 0xFF0000):
    """发送告警到所有渠道"""
    send_discord(title, message, color)
    send_feishu(title, message)
