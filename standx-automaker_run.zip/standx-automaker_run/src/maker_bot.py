"""
Maker Points 刷分机器人 (WebSocket 版本)
在 mark price 附近双边挂单，赚取 Maker Points

策略:
- 同时在买卖两侧挂限价单 (8 bps 距离)
- 通过 WebSocket 实时监控 mark price 变化，超过阈值则刷新订单
- 通过 WebSocket 实时监控订单成交，成交后立即平仓
- 确保订单存活 >3 秒以获得积分
"""

import asyncio
import json
import time
import os
import websockets
from enum import Enum
from typing import Optional, Callable, TYPE_CHECKING
from collections import deque
from pathlib import Path
from .rest_client import StandXClient
from .notify import send_alert
from config import (
    MIN_POSITION_THRESHOLD, WS_STREAM_URL,
    VOLATILITY_WINDOW,
    VOLATILITY_THRESHOLD_1, VOLATILITY_THRESHOLD_2, VOLATILITY_THRESHOLD_3,
    VOLATILITY_DISTANCE_1, VOLATILITY_DISTANCE_2, VOLATILITY_DISTANCE_3,
    MAKER_REFRESH_PERCENT, MAKER_DANGER_PERCENT
)

if TYPE_CHECKING:
    from .auth import StandXAuth


class MakerBotState(Enum):
    """机器人状态"""
    IDLE = "空闲"
    RUNNING = "运行中"
    CLOSING = "平仓中"
    STOPPED = "已停止"


class MakerBotWebSocket:
    """
    Maker Bot 专用 WebSocket 客户端
    同时订阅价格、订单、持仓三个频道
    """

    def __init__(self, auth: "StandXAuth", symbol: str,
                 on_price_update: Callable[[dict], None],
                 on_order_update: Callable[[dict], None],
                 on_position_update: Callable[[dict], None] = None):
        self.auth = auth
        self.symbol = symbol
        self.on_price_update = on_price_update
        self.on_order_update = on_order_update
        self.on_position_update = on_position_update
        self.ws_url = WS_STREAM_URL
        self.ws: Optional[websockets.WebSocketClientProtocol] = None
        self.running = False
        self.connected = False

    async def connect(self):
        """建立 WebSocket 连接"""
        while self.running:
            try:
                token = self.auth.get_token()

                async with websockets.connect(
                    self.ws_url,
                    ping_interval=None,
                    ping_timeout=None
                ) as ws:
                    self.ws = ws
                    self.connected = True
                    print(f"[WS] 已连接")

                    # 1. 发送认证 (订单和持仓频道需要)
                    auth_msg = {
                        "auth": {
                            "token": token,
                            "streams": [
                                {"channel": "order"},
                                {"channel": "position"}
                            ]
                        }
                    }
                    await ws.send(json.dumps(auth_msg))

                    # 2. 订阅价格频道
                    await ws.send(json.dumps({
                        "subscribe": {
                            "channel": "price",
                            "symbol": self.symbol
                        }
                    }))

                    # 3. 订阅订单频道
                    await ws.send(json.dumps({
                        "subscribe": {
                            "channel": "order"
                        }
                    }))

                    # 4. 订阅持仓频道
                    await ws.send(json.dumps({
                        "subscribe": {
                            "channel": "position"
                        }
                    }))

                    print(f"[WS] 已订阅 {self.symbol} 价格、订单、持仓频道")

                    # 接收消息循环
                    async for message in ws:
                        await self._handle_message(message)

            except websockets.ConnectionClosed as e:
                self.connected = False
                if self.running:
                    print(f"[WS] 连接关闭，重连中...")
            except Exception as e:
                self.connected = False
                if self.running:
                    print(f"[WS] 连接错误: {e}，重连中...")

            if self.running:
                await asyncio.sleep(0.1)

    async def _handle_message(self, message: str):
        """处理接收到的消息"""
        try:
            if message == "ping":
                await self.ws.send("pong")
                return

            data = json.loads(message)
            channel = data.get("channel")

            if channel == "price":
                price_data = data.get("data", {})
                if self.on_price_update:
                    self.on_price_update(price_data)

            elif channel == "order":
                order_data = data.get("data", {})
                if self.on_order_update:
                    self.on_order_update(order_data)

            elif channel == "position":
                position_data = data.get("data", {})
                if self.on_position_update:
                    self.on_position_update(position_data)

        except json.JSONDecodeError:
            pass
        except Exception as e:
            print(f"[WS] 处理消息错误: {e}")

    async def start(self):
        """启动 WebSocket"""
        self.running = True
        await self.connect()

    async def stop(self):
        """停止 WebSocket"""
        self.running = False
        self.connected = False
        if self.ws:
            await self.ws.close()


class MakerPointsBot:
    """Maker Points 刷分机器人 (WebSocket 版本)"""

    def __init__(self, client: StandXClient, auth: "StandXAuth", symbol: str,
                 order_size: float):
        """
        初始化机器人

        Args:
            client: REST API 客户端
            auth: 认证客户端 (用于 WebSocket)
            symbol: 交易对 (如 BTC-USD)
            order_size: 每边挂单数量
        """
        self.client = client
        self.auth = auth
        self.symbol = symbol
        self.order_size = order_size
        self.position_threshold = MIN_POSITION_THRESHOLD

        # 状态
        self.state = MakerBotState.IDLE
        self.running = False

        # WebSocket 客户端
        self.ws_client: Optional[MakerBotWebSocket] = None
        self._ws_task: Optional[asyncio.Task] = None

        # 实时数据 (来自 WebSocket)
        self.current_mark_price: Optional[float] = None
        self.current_position: float = 0.0

        # 当前订单信息
        self.bid_order_id: Optional[int] = None
        self.ask_order_id: Optional[int] = None
        self.bid_price: Optional[float] = None
        self.ask_price: Optional[float] = None
        self.last_mark_price: Optional[float] = None
        self.order_placed_time: Optional[float] = None

        # 成交检测
        self.pending_close = False

        # 统计
        self.session_start_time: Optional[float] = None
        self.orders_placed = 0
        self.orders_filled = 0
        self.close_count = 0  # 平仓次数
        self.close_fail_count = 0  # 平仓失败次数
        self.last_close_fail_alert = 0  # 上次平仓失败告警时间

        # 档位时间统计 (秒)
        self.tier1_time = 0.0  # 1档运行时间
        self.tier2_time = 0.0  # 2档运行时间
        self.tier3_time = 0.0  # 3档运行时间
        self.pause_time = 0.0  # 暂停时间
        self.last_tier_update = None  # 上次更新时间
        self.current_tier = 0  # 当前档位 (0=暂停, 1/2/3=档位)

        # 波动率检测
        self.price_history: deque = deque(maxlen=1000)  # (timestamp, price) 队列
        self.current_volatility: float = 0.0  # 当前波动率 (百分比)
        self.effective_target_bps: float = VOLATILITY_DISTANCE_1  # 实际使用的挂单距离 (初始使用1档)
        self.volatility_pause: bool = False  # 波动率过高时暂停挂单
        self.volatility_warmup: bool = True  # 波动率预热中
        self.volatility_warmup_remaining: float = 0.0  # 预热剩余时间（秒）

    def _on_price_update(self, price_data: dict):
        """WebSocket 价格更新回调"""
        mark = price_data.get("mark_price") or price_data.get("markPrice")
        if mark:
            price = float(mark)
            self.current_mark_price = price
            # 记录价格历史用于波动率计算
            self.price_history.append((time.time(), price))

    def _on_order_update(self, order_data: dict):
        """WebSocket 订单更新回调"""
        order_id = order_data.get("id")
        status = order_data.get("status", "").lower()
        symbol = order_data.get("symbol")

        # 只处理当前交易对的订单
        if symbol != self.symbol:
            return

        # 检查是否是我们的订单
        is_our_bid = order_id == self.bid_order_id
        is_our_ask = order_id == self.ask_order_id

        if not is_our_bid and not is_our_ask:
            return

        # 订单成交
        if status in ["filled", "partial_filled", "partially_filled"]:
            filled_qty = order_data.get("filled_qty") or order_data.get("filledQty", 0)
            side = order_data.get("side", "")
            print(f"\n  [成交] {side} 订单成交 {filled_qty}")
            self.orders_filled += 1
            self.pending_close = True

            # 清除已成交的订单ID和价格
            if is_our_bid:
                self.bid_order_id = None
                self.bid_price = None
            if is_our_ask:
                self.ask_order_id = None
                self.ask_price = None

        # 订单被取消 (通过 WebSocket 确认)
        elif status in ["cancelled", "canceled", "rejected"]:
            if is_our_bid:
                self.bid_order_id = None
                self.bid_price = None
            if is_our_ask:
                self.ask_order_id = None
                self.ask_price = None

    def _on_position_update(self, position_data: dict):
        """WebSocket 持仓更新回调"""
        symbol = position_data.get("symbol")

        # 只处理当前交易对的持仓
        if symbol != self.symbol:
            return

        qty = position_data.get("qty") or position_data.get("size") or 0
        self.current_position = float(qty)

    def _calculate_volatility(self) -> float:
        """
        计算最近时间窗口内的波动率 (百分比)
        波动率 = (最高价 - 最低价) / 最低价 × 100%
        """
        now = time.time()
        window_start = now - VOLATILITY_WINDOW

        # 过滤出窗口内的价格数据
        prices_in_window = [(t, p) for t, p in self.price_history if t >= window_start]

        # 检查预热状态：需要至少有窗口时间内的数据
        if len(prices_in_window) < 2:
            self.volatility_warmup = True
            self.volatility_warmup_remaining = VOLATILITY_WINDOW
            return 0.0

        # 检查预热状态：基于运行时间
        # 如果运行时间还不到 VOLATILITY_WINDOW 秒，则处于预热中
        if self.session_start_time:
            running_time = now - self.session_start_time
            if running_time < VOLATILITY_WINDOW:
                self.volatility_warmup = True
                self.volatility_warmup_remaining = VOLATILITY_WINDOW - running_time
            else:
                self.volatility_warmup = False
                self.volatility_warmup_remaining = 0.0
        else:
            # session_start_time 还未设置
            self.volatility_warmup = True
            self.volatility_warmup_remaining = VOLATILITY_WINDOW

        # 计算窗口内的最高价和最低价
        prices = [p for _, p in prices_in_window]
        high = max(prices)
        low = min(prices)

        # 波动率 = (high - low) / low * 100 (百分比)
        volatility = (high - low) / low * 100

        return volatility

    def _update_tier_time(self, new_tier: int):
        """更新档位时间统计"""
        now = time.time()
        if self.last_tier_update is not None:
            elapsed = now - self.last_tier_update
            if self.current_tier == 0:
                self.pause_time += elapsed
            elif self.current_tier == 1:
                self.tier1_time += elapsed
            elif self.current_tier == 2:
                self.tier2_time += elapsed
            elif self.current_tier == 3:
                self.tier3_time += elapsed
        self.current_tier = new_tier
        self.last_tier_update = now

    def _update_effective_distance(self) -> tuple:
        """
        根据波动率更新挂单距离

        Returns:
            (can_place, tier_changed)
            can_place: True 可以挂单, False 波动率过高或预热中禁止挂单
            tier_changed: True 档位变化需要强制刷新订单
        """
        self.current_volatility = self._calculate_volatility()
        old_distance = self.effective_target_bps

        # 预热期间禁止挂单
        if self.volatility_warmup:
            self._update_tier_time(0)  # 预热算暂停
            return (False, False)

        # 根据波动率确定挂单距离
        # 波动率 <= 阈值1: 使用配置1 (100% points 区间)
        # 波动率 <= 阈值2: 使用配置2 (50% points 区间)
        # 波动率 <= 阈值3: 使用配置3 (10% points 区间)
        # 波动率 > 阈值3: 禁止挂单
        if self.current_volatility > VOLATILITY_THRESHOLD_3:
            # 波动率过高，禁止挂单
            self._update_tier_time(0)  # 暂停
            if not self.volatility_pause:
                self.volatility_pause = True
                print(f"\n  [波动率] {self.current_volatility:.3f}% 超过阈值 {VOLATILITY_THRESHOLD_3}%，暂停挂单!")
            return (False, False)
        elif self.current_volatility <= VOLATILITY_THRESHOLD_1:
            new_distance = VOLATILITY_DISTANCE_1
            new_tier = 1
        elif self.current_volatility <= VOLATILITY_THRESHOLD_2:
            new_distance = VOLATILITY_DISTANCE_2
            new_tier = 2
        else:  # <= VOLATILITY_THRESHOLD_3
            new_distance = VOLATILITY_DISTANCE_3
            new_tier = 3

        # 更新档位时间
        self._update_tier_time(new_tier)

        # 恢复挂单
        if self.volatility_pause:
            self.volatility_pause = False
            print(f"\n  [波动率] {self.current_volatility:.3f}% 恢复正常，继续挂单")

        # 更新实际距离
        tier_changed = False
        if new_distance != old_distance:
            self.effective_target_bps = new_distance
            refresh_bps = new_distance * (MAKER_REFRESH_PERCENT / 100)
            danger_bps = new_distance * (MAKER_DANGER_PERCENT / 100)
            print(f"\n  [波动率] {self.current_volatility:.3f}% -> 距离:{new_distance:.0f}bp 刷新:{refresh_bps:.1f}bp 危险:{danger_bps:.1f}bp")
            # 档位变化，需要强制刷新订单
            if old_distance is not None and old_distance > 0:
                tier_changed = True

        return (True, tier_changed)

    def _calculate_prices(self, mark_price: float) -> Optional[tuple]:
        """
        计算挂单价格 (使用动态距离)
        注意: 会调用 _update_effective_distance() 检查波动率

        Returns:
            (bid_price, ask_price) 或 None (波动率过高时禁止挂单)
        """
        # 更新波动率和挂单距离
        can_place, _ = self._update_effective_distance()
        if not can_place:
            return None

        return self._calculate_order_prices(mark_price)

    def _calculate_order_prices(self, mark_price: float) -> tuple:
        """
        计算挂单价格 (使用当前 effective_target_bps)
        注意: 不检查波动率，需要先调用 _update_effective_distance()

        Returns:
            (bid_price, ask_price)
        """
        offset = mark_price * (self.effective_target_bps / 10000)
        bid_price = self._round_price(mark_price - offset)
        ask_price = self._round_price(mark_price + offset)
        return bid_price, ask_price

    def _round_price(self, price: float, tick_size: float = 0.01) -> float:
        """按照 tick size 格式化价格"""
        decimals = len(str(tick_size).split('.')[-1]) if '.' in str(tick_size) else 0
        return round(round(price / tick_size) * tick_size, decimals)

    def _get_position(self) -> float:
        """获取当前持仓数量 (REST API)"""
        try:
            positions = self.client.get_positions(self.symbol)
            data = positions.get("data", positions) if isinstance(positions, dict) else positions

            if isinstance(data, list):
                for pos in data:
                    if pos.get("symbol") == self.symbol:
                        return float(pos.get("qty", 0))
            return 0.0
        except Exception as e:
            print(f"  获取持仓失败: {e}")
            return 0.0

    def _check_existing_orders(self) -> bool:
        """
        检查并恢复现有订单

        Returns:
            True 如果找到并恢复了现有订单，False 否则
        """
        try:
            orders = self.client.get_open_orders(self.symbol)

            # 支持 data 或 result 字段
            if isinstance(orders, dict):
                data = orders.get("result") or orders.get("data") or orders
            else:
                data = orders

            if not isinstance(data, list) or len(data) == 0:
                return False

            bid_order = None
            ask_order = None

            for order in data:
                side = order.get("side", "").lower()
                status = order.get("status", "").lower()

                # 只处理活跃订单
                if status not in ["open", "new", "pending", "active", "working"]:
                    continue

                if side == "buy" and not bid_order:
                    bid_order = order
                elif side == "sell" and not ask_order:
                    ask_order = order

            # 如果两边都有订单，恢复状态
            if bid_order and ask_order:
                self.bid_order_id = bid_order.get("id") or bid_order.get("order_id")
                self.ask_order_id = ask_order.get("id") or ask_order.get("order_id")
                self.bid_price = float(bid_order.get("price", 0))
                self.ask_price = float(ask_order.get("price", 0))

                # 估算 last_mark_price 为买卖价的中间价
                self.last_mark_price = (self.bid_price + self.ask_price) / 2

                # 设置订单时间为当前时间，因为不知道实际挂单时间
                # 这样会导致首次检查时需要等待3.5秒才能刷新
                self.order_placed_time = time.time()

                print(f"  [恢复] 发现现有订单:")
                print(f"    买单: ${self.bid_price:,.2f} (ID: {self.bid_order_id})")
                print(f"    卖单: ${self.ask_price:,.2f} (ID: {self.ask_order_id})")
                return True

            # 只有单边订单，取消后重新挂
            if bid_order or ask_order:
                print(f"  [警告] 只有单边订单，将取消后重新挂单...")
                self._cancel_all_orders()
                return False

            return False

        except Exception as e:
            print(f"  检查现有订单失败: {e}")
            return False

    def _sync_orders_from_rest(self) -> bool:
        """
        从 REST API 同步订单状态 (WebSocket 断连时使用)

        Returns:
            True: 无活跃订单
            False: 还有活跃订单
        """
        try:
            orders = self.client.get_open_orders(self.symbol)
            if isinstance(orders, dict):
                data = orders.get("result") or orders.get("data") or orders
            else:
                data = orders

            if not isinstance(data, list) or len(data) == 0:
                # 无活跃订单
                self.bid_order_id = None
                self.ask_order_id = None
                self.bid_price = None
                self.ask_price = None
                return True

            # 还有活跃订单
            return False

        except Exception as e:
            print(f"  [警告] REST 查询订单失败: {e}")
            return False

    def _cancel_all_orders(self, max_retries: int = 3) -> bool:
        """
        取消所有委托 (带重试机制)

        流程:
        1. 发送 REST API 取消请求
        2. WebSocket 正常时: 等待 WebSocket 确认订单已取消
        3. WebSocket 断连时: 通过 REST API 查询确认订单状态

        Args:
            max_retries: 最大重试次数

        Returns:
            True: 成功取消或无订单
            False: 取消失败
        """
        for attempt in range(max_retries):
            try:
                self.client.cancel_all_orders(self.symbol)

                # 检查 WebSocket 是否连接正常
                ws_connected = self.ws_client and self.ws_client.connected

                if ws_connected:
                    # 等待 WebSocket 确认订单已取消 (最多等待 1 秒)
                    for _ in range(10):
                        if self.bid_order_id is None and self.ask_order_id is None:
                            return True
                        time.sleep(0.1)

                    # WebSocket 超时，降级到 REST 查询
                    if self.bid_order_id is not None or self.ask_order_id is not None:
                        print(f"  [警告] WebSocket 未确认取消，使用 REST 查询")
                        if self._sync_orders_from_rest():
                            return True
                        # REST 也确认还有订单，继续重试
                        continue
                else:
                    # WebSocket 断连，通过 REST API 确认
                    print(f"  [警告] WebSocket 断连，使用 REST 查询订单状态")
                    time.sleep(0.2)  # 等待服务器处理
                    if self._sync_orders_from_rest():
                        return True
                    # REST 确认还有订单，继续重试
                    continue

                return True

            except Exception as e:
                if attempt < max_retries - 1:
                    print(f"  取消委托失败 (重试 {attempt + 1}/{max_retries}): {e}")
                    time.sleep(0.1)
                else:
                    print(f"  取消委托失败 (已重试 {max_retries} 次): {e}")

        return False

    def _place_dual_orders(self, bid_price: float, ask_price: float) -> bool:
        """同时挂买单和卖单"""
        try:
            # 挂买单 (开多)
            bid_result, actual_bid = self.client.limit_long(
                symbol=self.symbol,
                size=self.order_size,
                price=bid_price,
                post_only=True
            )
            self.bid_price = actual_bid
            # 尝试获取订单ID
            if isinstance(bid_result, dict):
                self.bid_order_id = bid_result.get("id") or bid_result.get("order_id")

            # 挂卖单 (开空)
            ask_result, actual_ask = self.client.limit_short(
                symbol=self.symbol,
                size=self.order_size,
                price=ask_price,
                post_only=True
            )
            self.ask_price = actual_ask
            if isinstance(ask_result, dict):
                self.ask_order_id = ask_result.get("id") or ask_result.get("order_id")

            self.order_placed_time = time.time()
            self.orders_placed += 2

            return True

        except Exception as e:
            print(f"  挂单失败: {e}")
            return False

    def _close_position(self) -> bool:
        """市价平仓"""
        try:
            position = self._get_position()
            if abs(position) < self.position_threshold:
                return True

            print(f"  市价平仓: {position:.6f}")
            result = self.client.close_position(self.symbol)
            if result is not None:
                self.close_count += 1
                self.close_fail_count = 0  # 重置失败计数
                return True

            # 平仓失败
            self.close_fail_count += 1
            self._handle_close_failure(position, "API返回空结果")
            return False
        except Exception as e:
            self.close_fail_count += 1
            self._handle_close_failure(position if 'position' in dir() else 0, str(e))
            print(f"  平仓失败: {e}")
            return False

    def _handle_close_failure(self, position: float, error: str):
        """处理平仓失败 - 每15分钟最多推送一次"""
        now = time.time()
        # 距离上次告警超过15分钟才发送
        if now - self.last_close_fail_alert >= 900:  # 900秒 = 15分钟
            send_alert(
                "⚠️ StandX Bot 平仓失败",
                f"交易对: {self.symbol}\n"
                f"持仓量: {position:.6f}\n"
                f"失败次数: {self.close_fail_count}\n"
                f"错误: {error}",
                0xFF0000
            )
            self.last_close_fail_alert = now

    def _get_price_change_bps(self, current_mark: float) -> float:
        """获取 mark price 变化的 bps"""
        if self.last_mark_price is None:
            return 0.0
        return abs(current_mark - self.last_mark_price) / self.last_mark_price * 10000

    def _check_price_change(self, current_mark: float) -> bool:
        """检查 mark price 是否变化超过刷新阈值 (挂单距离的25%)"""
        refresh_threshold = self.effective_target_bps * (MAKER_REFRESH_PERCENT / 100)
        return self._get_price_change_bps(current_mark) >= refresh_threshold

    def _check_danger_price_change(self, current_mark: float) -> bool:
        """检查是否达到危险阈值 (挂单距离的40%，需要立即刷新，忽略存活时间)"""
        danger_threshold = self.effective_target_bps * (MAKER_DANGER_PERCENT / 100)
        return self._get_price_change_bps(current_mark) >= danger_threshold

    def _can_refresh_orders(self) -> bool:
        """检查是否可以刷新订单 (需要存活>3秒)"""
        if self.order_placed_time is None:
            return True
        elapsed = time.time() - self.order_placed_time
        return elapsed >= 3.5

    def _format_time(self, seconds: float) -> str:
        """格式化时间为 mm:ss"""
        m = int(seconds // 60)
        s = int(seconds % 60)
        return f"{m}:{s:02d}"

    def _print_status(self, mark_price: float, position: float):
        """打印状态 - 三行显示"""
        elapsed = time.time() - self.session_start_time if self.session_start_time else 0
        minutes = int(elapsed // 60)
        seconds = int(elapsed % 60)

        # 计算订单存活时间
        order_age = time.time() - self.order_placed_time if self.order_placed_time else 0
        order_age_sec = int(order_age)

        # 更新波动率 (确保预热状态实时更新)
        self.current_volatility = self._calculate_volatility()

        # 连接状态
        ws_icon = "*" if (self.ws_client and self.ws_client.connected) else "!"

        # 使用 ANSI 转义码: 清除从光标到屏幕末尾，然后上移三行
        print(f"\033[3A\033[J", end="")

        # 第一行: 价格信息 + 波动率 + 当前档位
        if self.volatility_warmup:
            remaining_sec = int(self.volatility_warmup_remaining)
            vol_str = f"波动:预热({remaining_sec}s)"
        else:
            dist_bp = int(self.effective_target_bps)
            vol_str = f"波动:{self.current_volatility:.3f}%/{dist_bp}bp"
            if self.volatility_pause:
                vol_str += "[暂停]"

        bid_str = f"${self.bid_price:,.2f}" if self.bid_price else "---"
        ask_str = f"${self.ask_price:,.2f}" if self.ask_price else "---"

        print(f"  {ws_icon} Mark:${mark_price:,.2f} | 买:{bid_str} | 卖:{ask_str} | {vol_str}")

        # 第二行: 订单状态
        price_change_bps = self._get_price_change_bps(mark_price)
        refresh_bps = self.effective_target_bps * (MAKER_REFRESH_PERCENT / 100)
        danger_bps = self.effective_target_bps * (MAKER_DANGER_PERCENT / 100)
        print(f"    数量:{self.order_size} | 仓位:{position:.6f} | 偏离:{price_change_bps:.1f}bp(刷新:{refresh_bps:.1f}/危险:{danger_bps:.1f}) | 存活:{order_age_sec}s")

        # 第三行: 档位时间统计 + 平仓次数
        t1 = self._format_time(self.tier1_time)
        t2 = self._format_time(self.tier2_time)
        t3 = self._format_time(self.tier3_time)
        tp = self._format_time(self.pause_time)
        print(f"    1档:{t1} | 2档:{t2} | 3档:{t3} | 暂停:{tp} | 平仓:{self.close_count} | 运行:{minutes}:{seconds:02d}")

        # 写入心跳文件
        self._write_heartbeat(mark_price, position)

    def _write_heartbeat(self, mark_price: float, position: float):
        """写入心跳文件供监控脚本检测"""
        try:
            heartbeat_file = Path(__file__).parent.parent / "heartbeat.txt"
            with open(heartbeat_file, "w") as f:
                f.write(f"{int(time.time())}\n")
                f.write(f"{self.symbol}\n")
                f.write(f"{mark_price:.2f}\n")
                f.write(f"{position:.6f}\n")
                f.write(f"{self.state.value}\n")
        except:
            pass  # 心跳写入失败不影响主逻辑

    async def _main_loop(self):
        """主循环"""
        self.session_start_time = time.time()
        last_print_time = 0

        while self.running:
            try:
                # 1. 获取 mark price (优先用 WebSocket，否则用 REST)
                if self.current_mark_price:
                    mark_price = self.current_mark_price
                else:
                    # 降级到 REST
                    try:
                        price_info = self.client.get_symbol_price(self.symbol)
                        mark = price_info.get("mark_price") or price_info.get("markPrice")
                        mark_price = float(mark) if mark else None
                    except:
                        mark_price = None

                if mark_price is None:
                    await asyncio.sleep(0.2)
                    continue

                # 2. 检查是否有待平仓 (来自 WebSocket 订单成交回调)
                if self.pending_close:
                    self.state = MakerBotState.CLOSING
                    print(f"\n  检测到成交，执行平仓...")
                    self._cancel_all_orders()
                    # 主动清除本地订单状态，确保下一轮会重新挂单
                    self.bid_order_id = None
                    self.ask_order_id = None
                    self.bid_price = None
                    self.ask_price = None
                    await asyncio.sleep(0.1)
                    if not self._close_position():
                        # 平仓失败，等待3秒后重试
                        await asyncio.sleep(3)
                        continue
                    self.pending_close = False
                    await asyncio.sleep(0.2)
                    continue

                # 3. 检查持仓 (使用 WebSocket 实时数据) - 只要有仓位就立即平仓
                position = self.current_position
                if position != 0:
                    self.state = MakerBotState.CLOSING
                    print(f"\n  检测到持仓 {position:.6f}，立即平仓...")
                    self._cancel_all_orders()
                    # 主动清除本地订单状态，确保下一轮会重新挂单
                    self.bid_order_id = None
                    self.ask_order_id = None
                    self.bid_price = None
                    self.ask_price = None
                    if not self._close_position():
                        # 平仓失败，等待3秒后重试
                        await asyncio.sleep(3)
                        continue
                    await asyncio.sleep(0.2)
                    continue

                self.state = MakerBotState.RUNNING

                # 4. 每次循环都检查波动率（不管有没有订单）
                can_place, tier_changed = self._update_effective_distance()

                # 波动率过高或预热中
                if not can_place:
                    # 如果有订单，需要取消
                    if self.bid_price is not None or self.ask_price is not None:
                        if self.volatility_warmup:
                            print(f"\n  [预热中] 取消所有挂单，等待预热完成...")
                        else:
                            print(f"\n  [波动率过高] 取消所有挂单...")
                        self._cancel_all_orders()
                        self.bid_order_id = None
                        self.ask_order_id = None
                        self.bid_price = None
                        self.ask_price = None
                    # 打印状态（预热/暂停期间也要显示）
                    now = time.time()
                    if now - last_print_time >= 1.0:
                        self._print_status(mark_price, position)
                        last_print_time = now
                    # 跳过挂单，等待条件恢复
                    await asyncio.sleep(0.5)
                    continue

                # 5. 波动率正常，计算挂单价格
                prices = self._calculate_order_prices(mark_price)

                # 5. 检查是否需要刷新订单
                need_refresh = False

                # 首次挂单
                if self.bid_price is None or self.ask_price is None:
                    need_refresh = True
                    print(f"\n  首次挂单...")

                # 波动率档位变化，强制刷新订单
                elif tier_changed:
                    need_refresh = True
                    print(f"\n  [档位变化] 强制刷新订单...")

                # 危险阈值: 价格变化过大，立即刷新 (忽略存活时间，防止被吃单)
                elif self._check_danger_price_change(mark_price):
                    need_refresh = True
                    change_bps = self._get_price_change_bps(mark_price)
                    print(f"\n  [危险] 价格变化 {change_bps:.1f}bps，立即刷新!")

                # 普通刷新: 价格变化超过阈值且满足存活时间
                elif self._check_price_change(mark_price) and self._can_refresh_orders():
                    need_refresh = True
                    print(f"\n  Mark price 变化，刷新订单...")

                # 6. 执行挂单
                if need_refresh:
                    # 必须先成功取消旧订单才能下新订单
                    if not self._cancel_all_orders():
                        print(f"  [错误] 取消订单失败，暂停 5 秒后重试...")
                        # 暂停较长时间，避免在订单状态不确定时继续操作
                        await asyncio.sleep(5)
                        # 再次尝试同步订单状态
                        self._sync_orders_from_rest()
                        continue

                    await asyncio.sleep(0.05)

                    bid_price, ask_price = prices
                    if self._place_dual_orders(bid_price, ask_price):
                        self.last_mark_price = mark_price
                        print(f"  买单: ${bid_price:,.2f} | 卖单: ${ask_price:,.2f}")

                # 6. 定期打印状态
                now = time.time()
                if now - last_print_time >= 1.0:
                    self._print_status(mark_price, position)
                    last_print_time = now

                await asyncio.sleep(0.1)  # WebSocket 版本可以更快

            except Exception as e:
                print(f"\n  主循环错误: {e}")
                await asyncio.sleep(1)

    async def start(self):
        """启动机器人"""
        print("\n" + "=" * 60)
        print("  [挂单做市模式] 作者：岳来岳会赚")
        print("  Twitter: @188888_x  TG: @Pacemak1r_8")
        print("  注册立享5%积分加成: standx.com/referral?code=YP9993")
        print("=" * 60)
        print(f"\n  启动中... 交易对: {self.symbol} | 单边数量: {self.order_size}")

        self.running = True
        self.state = MakerBotState.RUNNING

        # 检查现有订单
        print("  检查现有订单...")
        has_existing = self._check_existing_orders()
        if not has_existing:
            print("  无现有订单，将创建新订单")

        print("  按 Ctrl+C 停止")
        # 预留三行给状态显示
        print("")
        print("")
        print("")

        # 启动 WebSocket
        self.ws_client = MakerBotWebSocket(
            auth=self.auth,
            symbol=self.symbol,
            on_price_update=self._on_price_update,
            on_order_update=self._on_order_update,
            on_position_update=self._on_position_update
        )
        self._ws_task = asyncio.create_task(self.ws_client.start())

        # 等待 WebSocket 连接
        await asyncio.sleep(0.5)

        # 运行主循环
        await self._main_loop()

    async def stop(self):
        """停止机器人"""
        self.running = False
        self.state = MakerBotState.STOPPED

        print("\n\n  正在停止...")

        # 停止 WebSocket
        if self.ws_client:
            await self.ws_client.stop()
        if self._ws_task:
            self._ws_task.cancel()
            try:
                await self._ws_task
            except asyncio.CancelledError:
                pass

        # 取消所有委托
        self._cancel_all_orders()
        await asyncio.sleep(0.2)

        # 平仓
        position = self._get_position()
        if abs(position) >= self.position_threshold:
            print(f"  平仓: {position:.6f}")
            self._close_position()

        # 打印统计
        elapsed = time.time() - self.session_start_time if self.session_start_time else 0
        hours = int(elapsed // 3600)
        minutes = int((elapsed % 3600) // 60)

        print(f"\n{'=' * 60}")
        print(f"  Maker Points 机器人已停止")
        print(f"  运行时长: {hours}小时{minutes}分钟")
        print(f"  下单次数: {self.orders_placed}")
        print(f"  成交次数: {self.orders_filled}")
        print(f"{'=' * 60}")
