# StandX Maker Bot

StandX 交易所 **挂单做市机器人 + 刷量机器人**，通过智能挂单策略赚取 Maker Points 做市奖励。

**刷量效率**：约 100U 成本可获得 10,000 积分

## 作者：岳来岳会赚

- Twitter: [@188888_x](https://twitter.com/188888_x)
- Telegram: [@Pacemak1r_8](https://t.me/Pacemak1r_8)
- Discord: [https://discord.gg/KydzuuYp](https://discord.gg/KydzuuYp)

## StandX 注册

使用邀请链接注册 StandX 享受 **5% 推荐奖励**：

👉 [https://standx.com/referral?code=YP9993](https://standx.com/referral?code=YP9993)

## 两大核心功能

### 1. 挂单做市 (Maker Mode)
在买卖盘口两侧自动挂限价单，满足 StandX Maker Points 奖励条件：
- 订单距离在标记价格 10bp 以内
- 每小时至少 30 分钟有效挂单时间
- 挂单越久，奖励越多

### 2. 刷量模式 (Volume Mode)
通过高频挂撤单快速累积交易量和积分，成本极低。

## 核心特点

### 波动率智能控制
- **实时监控**：30 秒滚动窗口计算市场波动率
- **三档自适应**：低波动挂近(8bp)、中波动挂中(27bp)、高波动挂远(95bp)
- **自动暂停**：波动率过高时自动撤单暂停，保护资金安全
- **档位切换**：波动率档位变化时自动刷新订单位置

### 吃单即平仓
- **WebSocket 实时监听**：毫秒级订单成交检测
- **立即市价平仓**：订单被吃后第一时间平仓，避免持仓风险
- **零持仓运行**：始终保持空仓状态，不承担方向性风险

### 智能撤单刷新
- **价格偏离检测**：价格变化超过阈值自动刷新订单
- **危险阈值保护**：价格快速变化时立即撤单重挂，防止被吃
- **最小存活时间**：订单至少存活 3.5 秒才刷新，确保有效挂单时长

## 快速启动

推荐系统：**Ubuntu 22.04**

```bash
# 1. 克隆项目
git clone <repo-url>
cd standx-automaker

# 2. 配置私钥
cp .env.example .env
nano .env  # 填写 PRIVATE_KEY=0x你的私钥

# 3. 一键安装
./install.sh

# 4. 启动机器人
./start.sh
```

## 环境要求

- Python 3.8+
- BSC 钱包私钥

## 安装

```bash
# 克隆项目
git clone <repo-url>
cd standx-automaker

# 创建虚拟环境
python -m venv venv
source venv/bin/activate  # Linux/Mac
# 或 venv\Scripts\activate  # Windows

# 安装依赖
pip install -r requirements.txt
```

## 配置

### 1. 环境变量 (.env)

复制 `.env.example` 为 `.env` 并填写：

```bash
cp .env.example .env
```

编辑 `.env` 文件：

```env
# BSC 钱包私钥 (必须)
PRIVATE_KEY=0x你的私钥

# Ed25519 私钥 (可选，不填会自动生成临时密钥)
ED25519_KEY=

# 链类型 (可选，默认 bsc)
CHAIN=bsc
```

⚠️ **安全提示**：
- 私钥仅用于本地签名，不会上传到任何服务器
- 请勿将 `.env` 文件提交到 Git
- 建议使用专用的交易钱包，不要使用主钱包

### 2. 交易参数 (config/settings.py)

```python
# 交易对
SYMBOL = "BTC-PERP"

# 单边挂单数量 (USD)
ORDER_SIZE = 100

# 挂单存活时间 (秒)，订单至少存活这么久才会刷新
MIN_ORDER_LIFETIME = 3.5
```

### 3. 波动率配置 (config/settings.py)

机器人根据 30 秒滚动窗口的价格波动率自动调整挂单距离：

```python
# 波动率阈值 (百分比)
VOLATILITY_THRESHOLD_1 = 0.01   # <=0.01% 使用档位1
VOLATILITY_THRESHOLD_2 = 0.02   # <=0.02% 使用档位2
VOLATILITY_THRESHOLD_3 = 0.05   # <=0.05% 使用档位3，超过则暂停挂单

# 各档位挂单距离 (bp, 1bp = 0.01%)
VOLATILITY_DISTANCE_1 = 8    # 低波动: 8bp (0.08%)
VOLATILITY_DISTANCE_2 = 27   # 中波动: 27bp (0.27%)
VOLATILITY_DISTANCE_3 = 95   # 高波动: 95bp (0.95%)
```

### 4. 刷新阈值 (config/settings.py)

```python
# 刷新阈值: 价格变化达到挂单距离的 25% 时刷新订单
MAKER_REFRESH_PERCENT = 25

# 危险阈值: 价格变化达到挂单距离的 35% 时立即刷新 (忽略存活时间)
MAKER_DANGER_PERCENT = 35
```

## 使用

```bash
# 激活虚拟环境
source venv/bin/activate

# 运行机器人
python main.py
```

启动后按回车键开始挂单，按 `Ctrl+C` 停止。

## 状态显示说明

运行时会显示两行状态信息：

```
  * Mark:$94,500.00 | 买:$94,492.44 | 卖:$94,507.56 | 波动:0.012%/8bp
    数量:100 | 仓位:0.000000 | 偏离:1.2bp(刷新:2.0/危险:2.8) | 存活:5s | 运行:1:30
```

- `*` WebSocket 已连接 (`!` 表示断开)
- `Mark` 当前标记价格
- `买/卖` 当前挂单价格
- `波动` 当前波动率 / 使用的挂单距离档位
- `偏离` 价格偏离程度 (达到刷新/危险阈值会刷新订单)
- `存活` 当前订单存活时间
- `运行` 本次会话运行时长

## 工作原理

1. **启动预热**：收集 30 秒价格数据计算初始波动率
2. **双边挂单**：在标记价格上下按当前档位距离挂限价单
3. **实时监控**：通过 WebSocket 监控价格变化
4. **动态刷新**：
   - 价格偏离达到 25% 挂单距离且存活 >3.5 秒 → 刷新订单
   - 价格偏离达到 35% 挂单距离 → 立即刷新 (防止被吃单)
   - 波动率档位变化 → 强制刷新订单
5. **自动平仓**：订单成交后立即市价平仓
6. **波动暂停**：波动率超过最高阈值时取消订单并暂停

## 心跳监控

机器人运行时会写入心跳文件，配合监控脚本可在程序异常时发送告警通知。

### 配置 Webhook

在 `.env` 中添加（至少配置一个）：

```env
# Discord Webhook URL
DISCORD_WEBHOOK=https://discord.com/api/webhooks/xxx/xxx

# 飞书 Webhook URL
FEISHU_WEBHOOK=https://open.feishu.cn/open-apis/bot/v2/hook/xxx
```

### 启动监控

建议在 screen 中运行：

```bash
screen -S monitor
./monitor_heart.sh

# 退出 screen: Ctrl+A D
# 恢复 screen: screen -r monitor
```

### 监控参数

- 心跳写入：每 1 秒
- 检查间隔：每 10 秒
- 超时告警：15 秒无心跳

## 注意事项

1. **资金准备**：确保账户有足够的保证金
2. **风险控制**：虽然会自动平仓，但极端行情下可能产生滑点损失
3. **网络稳定**：建议在网络稳定的环境下运行
4. **参数调整**：根据实际情况调整波动率阈值和挂单距离

## 许可证

MIT License
